(function () {
  'use strict';

  // Only fixed classifications leave this isolated content script. Names, IDs,
  // credentials, client details and arbitrary portal text are never serialized.
  const normalize$1 = value => String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const statusText = value => normalize$1(value).replace(/^call status\s*:?\s*/, '');
  const STATUS_ELEMENTS = '[role="status"],.call-status,#callStatus,[data-call-status],h1,h2,h3,h4,h5,h6,span,p,strong,div,label';
  const labels = {
    signout: /^(sign\s*out|log\s*out|cerrar sesi[oó]n|salir)$/,
    accept: /^(accept( call)?|answer( call)?|aceptar( llamada)?|contestar( llamada)?)$/,
    reject: /^(reject( call)?|decline( call)?|rechazar( llamada)?)$/,
    hangup: /^(hang ?up|end call|disconnect call|colgar|finalizar llamada|terminar llamada)$/,
    idle: /^(start calls|stop calls|iniciar llamadas|detener llamadas)$/,
  };
  function controlKind(element) {
    for (const value of controlTexts(element)) {
      const label = normalize$1(value);
      for (const [kind, pattern] of Object.entries(labels)) if (pattern.test(label)) return kind;
    }
    return null;
  }
  function controlTexts(element) {
    const clean = element?.cloneNode?.(true);
    clean?.querySelectorAll?.('svg,mat-icon,.material-icons,.material-icons-outlined,[aria-hidden="true"]')?.forEach(icon => icon.remove());
    const value = element?.matches?.('input[type="button"],input[type="submit"]') ? element.value : null;
    return [element?.getAttribute?.('aria-label'), element?.getAttribute?.('title'), clean?.textContent ?? element?.textContent, value];
  }
  function visible(element) {
    if (!element || element.hidden || element.closest('[hidden],[aria-hidden="true"]') || !element.getClientRects().length) return false;
    const style = element.ownerDocument.defaultView.getComputedStyle(element);
    return style.visibility !== 'hidden' && style.display !== 'none';
  }
  function offlineStartButton(document) {
    const observation = readPortalObservation(document);
    if (observation.session !== 'authenticated' || observation.call !== 'idle') return null;
    const offline = [...document.querySelectorAll(STATUS_ELEMENTS)]
      .some(element => visible(element) && /^(offline|not available|no disponible|fuera de l[ií]nea|desconectado)$/.test(statusText(element.textContent)));
    if (!offline) return null;
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]')];
    const matches = controls.filter(element => visible(element) && !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
      controlTexts(element).some(value => /^(start calls|iniciar llamadas)$/.test(normalize$1(value))));
    return matches.length === 1 ? matches[0] : null;
  }
  function availableStopButton(document) {
    const observation = readPortalObservation(document);
    if (observation.session !== 'authenticated' || observation.call !== 'idle') return null;
    const available = [...document.querySelectorAll(STATUS_ELEMENTS)].some(element => visible(element) && /^(available|ready|disponible|wrap up|unavailable|line busy|rejected|call dropped)$/.test(statusText(element.textContent)));
    if (!available) return null;
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]')];
    const matches = controls.filter(element => visible(element) && !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
      controlTexts(element).some(value => /^(stop calls|detener llamadas)$/.test(normalize$1(value))));
    return matches.length === 1 ? matches[0] : null;
  }
  function readPortalObservation(document, armed = false) {
    const headings = [...document.querySelectorAll('h1,h2,h3,h4,strong,b,[role="heading"],header,nav,span,p,div,label')];
    const originalName = document.querySelector('app-header .app-interpreter-name');
    const originalWelcome = document.querySelector('app-header .header-welcome-message');
    const originalSession = visible(originalName) && /^.{1,180}\s*\(\d{1,12}\)$/.test(originalName.textContent.trim()) &&
      normalize$1(originalWelcome?.textContent) === normalize$1('Welcome, ' + originalName.textContent);
    const welcome = originalSession || headings.some(element => visible(element) && /^welcome,\s+.{1,180}\s*\(\d{1,12}\)$/i.test(element.textContent.trim()));
    const login = document.querySelector('#loginform');
    const session = welcome ? 'authenticated' : visible(login) ? 'logged-out' : 'unknown';
    if (session !== 'authenticated') return { session, call: 'unknown' };
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"],a[title],a[aria-label]')]
      .filter(element => visible(element) && !element.disabled && element.getAttribute('aria-disabled') !== 'true');
    const kinds = controls.map(controlKind);
    const statuses = [...document.querySelectorAll(STATUS_ELEMENTS)]
      .filter(visible).map(element => statusText(element.textContent));
    const connected = statuses.some(text => /^(call in progress|call connected|in call|llamada en curso|llamada conectada|en llamada)$/.test(text));
    const ended = statuses.some(text => /^(call ended|call disconnected|call completed|llamada terminada|llamada finalizada|llamada desconectada)$/.test(text));
    if (kinds.includes('hangup') && (connected || armed)) return { session, call: 'connected' };
    if (statuses.some(text => /^(ringing|enter code|sonando)$/.test(text))) return { session, call: 'incoming' };
    if (kinds.includes('accept') && kinds.includes('reject') && !kinds.includes('hangup')) return { session, call: 'incoming' };
    if (!kinds.includes('hangup') && (ended || kinds.includes('idle'))) return { session, call: 'idle' };
    return { session, call: 'unknown' };
  }

  function createPortalObserver({ document, send, documentId, now = () => Date.now(), trustedClick = event => event.isTrusted }) {
    let stopped = false, armedUntil = 0, previousCall = null, candidate = null, candidateAt = 0, committed = null, pendingSignal = null;
    let pendingAvailability = null, availabilityRevision = 0;
    async function sendManualAvailability() {
      const intent = pendingAvailability;
      if (!intent) return;
      try {
        const result = await send({ kind: 'portal-manual-availability', documentId, action: intent.action });
        if (result?.ok && pendingAvailability === intent) pendingAvailability = null;
      } catch { /* Retry a native choice after the next confirmed observation. */ }
    }
    function click(event) {
      if (!trustedClick(event)) return;
      const target = event.target?.closest?.('button,[role="button"],input,a');
      if (!visible(target) || readPortalObservation(document).session !== 'authenticated') return;
      const kind = controlKind(target);
      if (kind === 'idle' && (target === offlineStartButton(document) || target === availableStopButton(document))) {
        pendingAvailability = { action: target === availableStopButton(document) ? 'stop' : 'start', revision: ++availabilityRevision };
        void sendManualAvailability();
      }
      if (kind === 'signout') {
        // Send during capture, before the portal navigates away and destroys this
        // document. The worker waits for the resulting public-site navigation.
        try {
          Promise.resolve(send({ kind: 'portal-sign-out', documentId })).catch(error => {
            if (/extension context invalidated/i.test(String(error?.message))) stop();
          });
        } catch { /* A failed message never closes the shift. */ }
      }
      if (kind === 'accept') armedUntil = now() + 30000;
      if (kind === 'reject') pendingSignal = 'rejected';
    }
    async function sample() {
      if (stopped) return;
      const observation = readPortalObservation(document, now() < armedUntil);
      const key = `${observation.session}/${observation.call}`;
      if (key !== candidate) { candidate = key; candidateAt = now(); return; }
      // Require stable visible evidence across samples; a transient render is unknown.
      if (now() - candidateAt < 750) return;
      if (key !== committed) {
        if (observation.session === 'authenticated') {
          if (observation.call === 'connected' && (previousCall === 'idle' || previousCall === 'incoming' || now() < armedUntil)) pendingSignal = 'accepted';
          if ((observation.call === 'idle' || observation.call === 'incoming') && previousCall === 'connected') pendingSignal = 'disconnected';
          else if (observation.call === 'incoming') pendingSignal = 'incoming';
          if (observation.call !== 'unknown') previousCall = observation.call;
          if (observation.call === 'connected' || observation.call === 'idle') armedUntil = 0;
        } else if (observation.session === 'logged-out') { previousCall = null; armedUntil = 0; pendingSignal = null; }
        committed = key;
      }
      try {
        const offline = Boolean(offlineStartButton(document));
        const available = Boolean(availableStopButton(document));
        const revision = availabilityRevision;
        const requestedAt = now();
        const result = await send({ kind: 'portal-observation', documentId, observedAt: new Date(requestedAt).toISOString(), ...observation, offline, available, ...(pendingSignal ? { signal: pendingSignal } : {}) });
        if (result?.ok) pendingSignal = null;
        if (pendingAvailability) { await sendManualAvailability(); return result; }
        if (revision !== availabilityRevision) return result;
        const action = result?.prepare === true && offline ? 'start' : result?.stopCalls === true && available ? 'stop' : null;
        if (action && result.commandId && now() >= requestedAt && now() - requestedAt <= 3000 && Date.parse(result.authorizationUntil) > now()) {
          const confirmed = await send({ kind: 'confirm-automation-action', documentId, commandId: result.commandId });
          const current = readPortalObservation(document);
          if (!stopped && revision === availabilityRevision && !pendingAvailability && confirmed?.ok && now() - requestedAt <= 3000 &&
              now() >= requestedAt && Date.parse(confirmed.authorizationUntil) > now() && current.session === 'authenticated' && current.call === 'idle') {
            (action === 'start' ? offlineStartButton(document) : availableStopButton(document))?.click();
          }
        }
        return result;
      } catch (error) {
        if (/extension context invalidated/i.test(String(error?.message))) stop();
      }
    }
    function stop() { stopped = true; document.removeEventListener('click', click, true); }
    document.addEventListener('click', click, true);
    return { sample, stop, isStopped: () => stopped };
  }

  function parsePortalNumber(value) {
    let text = String(value ?? '').trim().replace(/^(-?)\s*(?:USD\s*|\$\s*)/i, '$1').replace(/[\s\u00a0]/g, '');
    if (!/^-?(?:\d[\d.,]*|[.,]\d+)$/.test(text)) return null;
    if (text.includes(',') && text.includes('.')) {
      const decimal = text.lastIndexOf(',') > text.lastIndexOf('.') ? ',' : '.';
      const group = decimal === ',' ? '.' : ',';
      const parts = text.split(decimal);
      if (parts.length !== 2 || !/^\d+$/.test(parts[1])) return null;
      const escaped = group === '.' ? '\\.' : ',';
      if (!new RegExp(`^-?\\d{1,3}(?:${escaped}\\d{3})+$`).test(parts[0])) return null;
      text = text.split(group).join('').replace(decimal, '.');
    } else if (text.includes(',')) {
      text = /^-?\d{1,3}(?:,\d{3})+$/.test(text) ? text.replace(/,/g, '') : text.replace(',', '.');
    }
    if (!/^-?(?:\d+(?:\.\d+)?|\.\d+)$/.test(text)) return null;
    const number = Number(text);
    return Number.isFinite(number) && Math.abs(number) <= 100000000 ? number : null;
  }

  function summarizePortalRows(rows) {
    let minutesUnits = 0, payUnits = 0, missingMinutes = 0, missingPay = 0;
    for (const row of rows) {
      const minutes = parsePortalNumber(row.minutes), pay = parsePortalNumber(row.pay);
      if (minutes === null || minutes < 0) missingMinutes++;
      else minutesUnits += Math.round(minutes * 1000000);
      if (pay === null) missingPay++;
      else payUnits += Math.round(pay * 1000000);
    }
    return { count: rows.length, minutes: minutesUnits / 1000000, pay: payUnits / 1000000, missingMinutes, missingPay };
  }

  const normalize = value => String(value).toLowerCase().replace(/[^a-z]/g, '');
  function portalColumns(headers) {
    const names = headers.map(normalize);
    const minutes = names.findIndex(name => ['durationminutes', 'durationmin', 'durationmins'].includes(name));
    const pay = names.indexOf('pay');
    const history = names.some(name => ['customerid', 'calldate', 'callstart'].includes(name));
    return minutes >= 0 && pay >= 0 && history ? { minutes, pay } : null;
  }

  function readPortalHistory(document, visible = element => !element.hidden) {
    const tables = [...document.querySelectorAll('table, mat-table, [role="table"], [role="grid"]')];
    for (const table of tables) {
      if (!visible(table)) continue;
      const header = table.querySelector('tr:has(th), mat-header-row, [role="row"]:has([role="columnheader"])');
      if (!header) continue;
      const headers = [...header.querySelectorAll('th, mat-header-cell, [role="columnheader"]')];
      const columns = portalColumns(headers.map(cell => cell.innerText ?? cell.textContent));
      if (!columns) continue;
      const rows = [];
      for (const row of table.querySelectorAll('tbody tr, mat-row, [role="row"]')) {
        if (row === header || !visible(row) || row.closest('table, mat-table, [role="table"], [role="grid"]') !== table) continue;
        if (row.matches('tfoot tr, .mat-footer-row, .mat-mdc-footer-row')) continue;
        const cells = [...row.children].filter(cell => cell.matches('td, mat-cell, [role="cell"], [role="gridcell"]'));
        if (cells.length !== headers.length || cells.some(cell => Number(cell.getAttribute('colspan') || 1) !== 1)) continue;
        // Only read the two numeric columns, never customer identifiers or call details.
        rows.push({ minutes: cells[columns.minutes].innerText ?? cells[columns.minutes].textContent,
          pay: cells[columns.pay].innerText ?? cells[columns.pay].textContent });
      }
      return { table, summary: summarizePortalRows(rows), signature: JSON.stringify(rows) };
    }
    return null;
  }

  function validatePortalRecord(value, now = Date.now()) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const { customerId, callDate, callStart, billable, dropped } = value;
    if (typeof customerId !== 'string' || !/^\d{1,20}$/.test(customerId)) return null;
    const date = typeof callDate === 'string' && callDate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    const clock = typeof callStart === 'string' && callStart.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (!date || !clock || !/^(Yes|No)$/i.test(billable || '') || !/^(Yes|No)$/i.test(dropped || '')) return null;
    const [month, day, year] = date.slice(1).map(Number), hour = Number(clock[1]), minute = Number(clock[2]);
    if (year < 2000 || year > 2100 || hour < 1 || hour > 12 || minute > 59) return null;
    const start = new Date(year, month - 1, day, hour % 12 + (clock[3].toUpperCase() === 'PM' ? 12 : 0), minute);
    if (start.getFullYear() !== year || start.getMonth() !== month - 1 || start.getDate() !== day) return null;
    const durationMin = parsePortalNumber(value.durationMin), amount = parsePortalNumber(value.pay);
    if (durationMin === null || durationMin < 0 || durationMin > 1440 || amount === null || amount < 0 || amount > 100000) return null;
    if (start.getTime() + durationMin * 60000 > now) return null;
    return { customerId, callDate, callStart: `${hour}:${String(minute).padStart(2, '0')} ${clock[3].toUpperCase()}`,
      durationMin, billable: /^yes$/i.test(billable) ? 'Yes' : 'No', dropped: /^yes$/i.test(dropped) ? 'Yes' : 'No', pay: `$${amount.toFixed(2)}` };
  }

  function readPortalRecords(table, visible, now = Date.now()) {
    const header = table.querySelector('tr:has(th), mat-header-row, [role="row"]:has([role="columnheader"])');
    if (!header) return null;
    const headers = [...header.querySelectorAll('th, mat-header-cell, [role="columnheader"]')];
    const names = headers.map(cell => String(cell.innerText ?? cell.textContent).toLowerCase().replace(/[^a-z]/g, ''));
    const columns = ['customerid', 'calldate', 'callstart', 'durationminutes', 'billable', 'dropped', 'pay'].map(name => names.indexOf(name));
    if (columns[3] < 0) columns[3] = names.findIndex(name => ['durationmin', 'durationmins'].includes(name));
    if (columns.some(index => index < 0)) return null;
    const records = []; let invalid = 0;
    for (const row of table.querySelectorAll('tbody tr, mat-row, [role="row"]')) {
      if (row === header || !visible(row) || row.closest('table, mat-table, [role="table"], [role="grid"]') !== table || row.matches('tfoot tr, .mat-footer-row, .mat-mdc-footer-row')) continue;
      const cells = [...row.children].filter(cell => cell.matches('td, mat-cell, [role="cell"], [role="gridcell"]'));
      if (cells.length !== headers.length || cells.some(cell => Number(cell.getAttribute('colspan') || 1) !== 1)) { invalid++; continue; }
      const fields = columns.map(index => String(cells[index].innerText ?? cells[index].textContent).trim());
      const record = validatePortalRecord(Object.fromEntries(['customerId', 'callDate', 'callStart', 'durationMin', 'billable', 'dropped', 'pay'].map((key, i) => [key, fields[i]])), now);
      if (record) records.push(record); else invalid++;
    }
    return { records, invalid };
  }

  function parsePortalRange(value) {
    const text = String(value).replace(/,/g, '').trim();
    if (/^0\s+(?:of|de)\s+0$/i.test(text)) return { start: 0, end: 0, total: 0 };
    const match = text.match(/^(\d+)\s*[-–—]\s*(\d+)\s+(?:of|de)\s+(\d+)$/i);
    if (!match) return null;
    const [start, end, total] = match.slice(1).map(Number);
    if (![start, end, total].every(Number.isSafeInteger) || start < (total ? 1 : 0) || end < start || end > total) return null;
    return { start, end, total };
  }

  function readPortalPaginator(table, visible) {
    for (let ancestor = table.parentElement; ancestor; ancestor = ancestor.parentElement) {
      const candidates = [...ancestor.querySelectorAll('mat-paginator, .mat-mdc-paginator, .mat-paginator')].filter(visible);
      if (candidates.length > 1) return null;
      if (!candidates.length) continue;
      const element = candidates[0];
      const range = parsePortalRange(element.querySelector('.mat-mdc-paginator-range-label, .mat-paginator-range-label')?.textContent);
      if (!range) return null;
      const sizeText = element.querySelector('.mat-mdc-paginator-page-size-select, .mat-paginator-page-size-select, .mat-mdc-paginator-page-size-value, .mat-paginator-page-size-value')?.textContent;
      const size = Number(String(sizeText || '').match(/\d+/)?.[0]);
      if (!Number.isSafeInteger(size) || size < 1) return null;
      const buttons = {};
      for (const action of ['first', 'previous', 'next']) {
        buttons[action] = element.querySelector(`button.mat-mdc-paginator-navigation-${action}, button.mat-paginator-navigation-${action}`);
      }
      return { element, range: { ...range, size }, buttons };
    }
    return null;
  }

  function portalRangeContext(document, table) {
    return JSON.stringify([document.location.pathname,
      [...document.querySelectorAll('input.mat-datepicker-input, input[type="date"]')].map(input => input.value),
      [...table.querySelectorAll('[aria-sort]')].map(cell => cell.getAttribute('aria-sort'))]);
  }

  async function collectPortalPages({ read, move, signal, progress = () => {}, canRestore = () => true }) {
    const original = read();
    if (!original?.range) throw new Error('No se reconoce la paginación del historial.');
    const { total, size } = original.range;
    if (Math.ceil(total / size) > 2000) throw new Error('El período es demasiado grande. Elegí un rango de fechas más corto.');
    const pages = new Map();
    let current = original, restorationError;
    function check(snapshot, restoring = false) {
      if (!restoring && signal?.aborted) throw new Error('Cálculo cancelado.');
      if (!snapshot?.range || snapshot.context !== original.context || snapshot.range.total !== total || snapshot.range.size !== size) {
        throw new Error('El historial cambió durante el cálculo. Volvé a sumar el período.');
      }
      const { start, end } = snapshot.range;
      if (snapshot.summary.count !== (total ? end - start + 1 : 0)) throw new Error('La página todavía no muestra todas sus llamadas.');
      return snapshot;
    }
    async function step(action, restoring = false) {
      const before = check(read(), restoring);
      const after = check(await move(action, { restoring }), restoring);
      const expected = action === 'first' ? 1 : action === 'previous' ? Math.max(1, before.range.start - size) : before.range.start + size;
      if (after.range.start !== expected || after.range.end !== Math.min(total, expected + size - 1)) throw new Error('La paginación no avanzó como se esperaba.');
      current = after;
    }
    try {
      check(current);
      if (total && current.range.start !== 1 && current.hasFirst) await step('first');
      while (total && current.range.start !== 1) await step('previous');
      let count = 0;
      do {
        current = check(read());
        if (pages.has(current.range.start) || current.range.start !== (count ? count + 1 : total ? 1 : 0)) throw new Error('Falta una página del historial; no se mostrará un total incompleto.');
        pages.set(current.range.start, { signature: current.signature, summary: current.summary });
        count += current.summary.count;
        progress(count, total);
        if (current.range.end === total) break;
        await step('next');
      } while (pages.size <= 2000);
      if (count !== total) throw new Error('No se pudieron leer todas las llamadas del período.');
    } finally {
      try {
        const latest = read();
        if (canRestore() && latest?.context === original.context && latest.range.total === total && latest.range.size === size) {
          current = latest;
          if (current.range.start !== original.range.start && current.hasFirst && (original.range.start === 1 || current.range.start - original.range.start > original.range.start - 1)) await step('first', true);
          while (current.range.start > original.range.start) await step('previous', true);
          while (current.range.start < original.range.start) await step('next', true);
        }
      } catch (error) { restorationError = error; }
    }
    if (restorationError) throw new Error('Se leyeron las llamadas, pero no se pudo volver a tu página inicial. Volvé a calcular.');
    const summaries = [...pages.values()].map(page => page.summary);
    const summary = { count: total, minutes: 0, pay: 0, missingMinutes: 0, missingPay: 0 };
    for (const name of ['minutes', 'pay']) summary[name] = summaries.reduce((sum, page) => sum + Math.round(page[name] * 1000000), 0) / 1000000;
    for (const name of ['missingMinutes', 'missingPay']) summary[name] = summaries.reduce((sum, page) => sum + page[name], 0);
    return { summary, pages, context: original.context, total, size };
  }

  function createHistoryObserver({ document, documentId, send, now = () => Date.now() }) {
    const visible = element => !element.hidden && element.getClientRects().length > 0 && document.defaultView.getComputedStyle(element).visibility !== 'hidden';
    let enabled = false, stopped = false, candidate = '', candidateAt = 0, sent = '', running = null, scanned = '', lastScanAt = 0;
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    function snapshot() {
      const found = readPortalHistory(document, visible);
      if (!found) return null;
      const pager = readPortalPaginator(found.table, visible);
      const rows = enabled ? readPortalRecords(found.table, visible, now()) : { records: [], invalid: 0 };
      if (!rows) return null;
      return { ...found, ...rows, pager, range: pager?.range, context: portalRangeContext(document, found.table), hasFirst: Boolean(pager?.buttons.first) };
    }
    async function publish(found, coverage = 'page', records = found.records, count = found.summary.count, invalid = found.invalid) {
      for (let i = 0; i < Math.max(1, records.length); i += 100) {
        const result = await send({ kind: 'portal-history', documentId, count, invalid, coverage, records: records.slice(i, i + 100) });
        if (!result?.ok) return false;
      }
      return true;
    }
    function todayRange() {
      const day = new Date(now()), iso = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}`;
      const us = `${day.getMonth() + 1}/${day.getDate()}/${day.getFullYear()}`;
      const long = day.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
      const fields = [...document.querySelectorAll('input.mat-datepicker-input, input[type="date"]')].filter(visible);
      return fields.length === 2 && fields.every(input => [iso, us, long, us.replace(/^(\d)\//, '0$1/').replace(/\/(\d)\//, '/0$1/')].includes(input.value.trim()));
    }
    async function scan(initial) {
      const key = `${initial.context}|${initial.range.total}`;
      if (running || document.documentElement.dataset.propioHistoryScan || !todayRange() || initial.range.total > 2000 || (scanned === key && now() - lastScanAt < 30000)) return;
      scanned = key; lastScanAt = now();
      const run = running = { controller: new AbortController(), context: initial.context, external: false };
      document.documentElement.dataset.propioHistoryScan = 'recovery';
      const pages = new Map();
      try {
        const read = () => {
          const found = snapshot();
          if (found && !run.controller.signal.aborted && found.range) pages.set(found.range.start, found);
          return found;
        };
        await collectPortalPages({ read, signal: run.controller.signal, canRestore: () => !run.external,
          move: async action => {
            const before = snapshot(), button = before?.pager?.buttons[action];
            if (!button || button.disabled || button.getAttribute('aria-disabled') === 'true') throw Error('Paginación no disponible');
            const expected = action === 'first' ? 1 : action === 'previous' ? Math.max(1, before.range.start - before.range.size) : before.range.start + before.range.size;
            let changedAt = 0;
            const observer = new document.defaultView.MutationObserver(() => { changedAt = now(); });
            observer.observe(before.table, { childList: true, subtree: true, characterData: true });
            try {
              button.click(); const deadline = now() + 15000;
              while (now() < deadline) {
                if (run.external) throw Error('Historial cambiado');
                const found = snapshot();
                if (!found || found.context !== run.context) throw Error('Historial cambiado');
                const loading = found.table.closest('[aria-busy="true"]') || [...found.table.parentElement.querySelectorAll('[role="progressbar"],mat-progress-bar,mat-progress-spinner')].some(visible);
                if (changedAt && now() - changedAt >= 250 && !loading && found.range?.start === expected && found.summary.count === found.range.end - found.range.start + 1) return found;
                await pause(80);
              }
              throw Error('Historial sin confirmar');
            } finally { observer.disconnect(); }
          } });
        if (!run.controller.signal.aborted && !run.external) {
          const values = [...pages.values()], records = values.flatMap(page => page.records), invalid = values.reduce((sum, page) => sum + page.invalid, 0);
          if (await publish(initial, 'range', records, initial.range.total, invalid)) { scanned = key; lastScanAt = now(); }
        }
      } catch { /* Keep the visible-page recovery; a partial scan never claims full coverage. */ }
      finally { if (document.documentElement.dataset.propioHistoryScan === 'recovery') delete document.documentElement.dataset.propioHistoryScan; running = null; }
    }
    function interrupt(event) {
      if (running && (event.type !== 'click' || event.isTrusted)) { running.external = true; running.controller.abort(); }
    }
    for (const kind of ['click', 'input', 'change']) document.addEventListener(kind, interrupt, true);
    async function sample(historyEnabled) {
      if (stopped) return;
      if (typeof historyEnabled === 'boolean' && enabled !== historyEnabled) {
        enabled = historyEnabled; candidate = ''; sent = ''; scanned = '';
        if (!enabled) running?.controller.abort();
      }
      if (running || document.documentElement.dataset.propioHistoryScan) return;
      const found = snapshot();
      if (!found) { candidate = ''; sent = ''; return; }
      const key = JSON.stringify([found.context, found.range, found.signature, found.records, found.invalid, enabled]);
      if (key !== candidate) { candidate = key; candidateAt = now(); return; }
      if (now() - candidateAt < 750) return;
      if (key !== sent && await publish(found)) sent = key;
      if (enabled && found.pager && found.range.total > found.summary.count) void scan(found);
    }
    function stop() { stopped = true; running?.controller.abort(); for (const kind of ['click', 'input', 'change']) document.removeEventListener(kind, interrupt, true); }
    return { sample, stop };
  }

  if (location.origin === 'https://interpreters.propio-ls.com' && window.top === window) {
    const context = { document, documentId: crypto.randomUUID(), send: packet => chrome.runtime.sendMessage(packet) };
    const observer = createPortalObserver(context), history = createHistoryObserver(context);
    let inFlight = null;
    function stop() {
      observer.stop(); history.stop(); clearInterval(timer);
      window.removeEventListener('pageshow', tick);
      document.removeEventListener('visibilitychange', tick);
      document.removeEventListener('resume', tick);
      try { chrome.runtime.onMessage.removeListener(onMessage); } catch { /* The extension may already be reloaded. */ }
    }
    const tick = () => {
      if (!inFlight) inFlight = sample().finally(() => { inFlight = null; });
      return inFlight;
    };
    async function sample() {
      if (observer.isStopped()) { stop(); return; }
      try {
        if (!chrome.runtime.id) { stop(); return; }
        const reply = await observer.sample(); await history.sample(reply?.historyEnabled);
      } catch { stop(); }
    }
    function onMessage(message, sender, respond) {
      if (sender.id !== chrome.runtime.id || message?.kind !== 'sample-portal') return;
      tick().then(() => respond({ ok: !observer.isStopped() }), () => respond({ ok: false }));
      return true;
    }
    const timer = setInterval(tick, 1000);
    window.addEventListener('pagehide', event => { if (!event.persisted) stop(); });
    window.addEventListener('pageshow', tick);
    document.addEventListener('visibilitychange', tick);
    document.addEventListener('resume', tick);
    chrome.runtime.onMessage.addListener(onMessage);
    void tick();
  }

})();
