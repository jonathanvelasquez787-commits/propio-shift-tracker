import { workspacePages, validateWorkspaceSettings } from './workspace-settings.js';
const lockKey = 'workday-workspace-lock';

export function workspaceBounds(screen, frameInset = 8, rightPaneHeightRatio = 1, rightPaneWidthRatio = 5 / 16) {
  const width = Math.round(screen.availWidth), height = Math.round(screen.availHeight);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width < 900 || height < 500) {
    throw new Error('Necesitás una pantalla de al menos 900 × 500 para esta distribución.');
  }
  const left = Math.round(screen.availLeft || 0), top = Math.round(screen.availTop || 0);
  const inset = Number.isFinite(frameInset) ? Math.max(0, Math.min(16, frameInset)) : 8;
  const widthRatio = Number.isFinite(rightPaneWidthRatio) && rightPaneWidthRatio >= .25 && rightPaneWidthRatio <= .5 ? rightPaneWidthRatio : 5 / 16;
  const rightContentWidth = Math.max(320, Math.round(width * widthRatio));
  const rightWidth = rightContentWidth + 2 * inset;
  const ratio = typeof rightPaneHeightRatio === 'number' && Number.isFinite(rightPaneHeightRatio) && rightPaneHeightRatio >= .4 && rightPaneHeightRatio <= 1 ? rightPaneHeightRatio : 1;
  // Overlap invisible side borders and extend the bottom border past the work area.
  return {
    left: { left, top, width: width - rightContentWidth, height: height + inset },
    right: { left: left + width - rightWidth, top, width: rightWidth, height: Math.round(height * ratio) + inset }
  };
}

export async function arrangeWorkspace(api, screen, { at = Date.now(), frameInset = 8, rightPaneHeightRatio = 1, rightPaneWidthRatio = 5 / 16, configuration = null, wait = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
  const pages = configuration ? validateWorkspaceSettings(configuration).pages : workspacePages;
  if (typeof api.tabs.createSplit !== 'function' || typeof api.tabs.unsplit !== 'function') {
    throw new Error('Chrome necesita tener disponible la vista dividida para extensiones (versión 155 o posterior).');
  }
  const bounds = workspaceBounds(screen, frameInset, rightPaneHeightRatio, rightPaneWidthRatio);
  const launcher = await api.tabs.getCurrent();
  if (!launcher || launcher.incognito) throw new Error('Abrí el espacio de trabajo en tu perfil habitual de Chrome.');
  const owner = `${launcher.id}:${at}`;
  const previous = (await api.storage.session.get(lockKey))[lockKey];
  if (previous && at - previous.at < 90000) return { status: 'already-running' };
  await api.storage.session.set({ [lockKey]: { owner, at } });
  await wait(300);
  if ((await api.storage.session.get(lockKey))[lockKey]?.owner !== owner) return { status: 'already-running' };
  try {
    // Dejá terminar la restauración antes de buscar pestañas para no duplicarlas.
    await wait(1200);
    const results = await Promise.all(Object.entries(pages).map(([key, url]) => api.tabs.query({ url: key === 'dictionary' ? ['https://www.linguee.es/*', 'https://www.linguee.com/*'] : `${new URL(url).origin}/*`, windowType: 'normal' })));
    for (let index = 0; index < results.length; index++) {
      results[index] = results[index].filter(tab => !tab.incognito);
      if (index < 3 && results[index].length > 1) throw new Error('Hay varias pestañas de una página de trabajo. Conservá una de cada una antes de organizar.');
    }
    let [portal, interpreter, tracker] = results.map(tabs => tabs[0]);
    if (!portal) portal = await api.tabs.create({ windowId: launcher.windowId, url: pages.portal, active: false });
    const leftId = portal.windowId;
    if (Number.isInteger(tracker?.splitViewId) && tracker.splitViewId >= 0) {
      await api.tabs.unsplit(tracker.splitViewId);
      portal = await api.tabs.get(portal.id);
    }
    if (!tracker || tracker.windowId === leftId) {
      const right = await api.windows.create(tracker ? { tabId: tracker.id, type: 'normal', focused: false } : { url: pages.tracker, type: 'normal', focused: false });
      tracker = tracker ? await api.tabs.get(tracker.id) : right.tabs[0];
    }
    if (!interpreter) interpreter = await api.tabs.create({ windowId: leftId, url: pages.interpreter, active: false });
    const alreadySplit = portal.windowId === interpreter.windowId && portal.splitViewId >= 0 && portal.splitViewId === interpreter.splitViewId && interpreter.index === portal.index + 1;
    if (!alreadySplit) {
      const splits = new Set([portal.splitViewId, interpreter.splitViewId].filter(id => Number.isInteger(id) && id >= 0));
      for (const split of splits) await api.tabs.unsplit(split);
      for (const tab of [portal, interpreter]) {
        if (tab.pinned) await api.tabs.update(tab.id, { pinned: false });
        if (tab.groupId >= 0) await api.tabs.ungroup(tab.id);
      }
      await api.tabs.move([portal.id, interpreter.id], { windowId: leftId, index: 0 });
      await api.tabs.createSplit([portal.id, interpreter.id]);
    }
    let dictionary = results[3].find(tab => tab.windowId === tracker.windowId) || results[3][0];
    if (!dictionary) dictionary = await api.tabs.create({ windowId: tracker.windowId, url: pages.dictionary, active: false });
    if (Number.isInteger(dictionary.splitViewId) && dictionary.splitViewId >= 0) await api.tabs.unsplit(dictionary.splitViewId);
    await api.tabs.move([tracker.id, dictionary.id], { windowId: tracker.windowId, index: 0 });
    for (const [id, geometry] of [[leftId, bounds.left], [tracker.windowId, bounds.right]]) {
      await api.windows.update(id, { state: 'normal' });
      await api.windows.update(id, { ...geometry, focused: false });
    }
    await api.tabs.update(portal.id, { active: true });
    await api.tabs.update(tracker.id, { active: true });
    await api.windows.update(tracker.windowId, { focused: true });
    return { status: 'ready', portal: portal.id, interpreter: interpreter.id, tracker: tracker.id, dictionary: dictionary.id };
  } finally {
    if ((await api.storage.session.get(lockKey))[lockKey]?.owner === owner) await api.storage.session.remove(lockKey);
  }
}
