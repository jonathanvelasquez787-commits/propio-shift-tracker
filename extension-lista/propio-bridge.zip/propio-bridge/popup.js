(function () {
  'use strict';

  const AUTOMATION_STATUS_MAX_AGE = 15000;
  const reasons$1 = new Set(['connection','schedule','shift-ended','before-shift','review','in-call','incoming','portal-state',
    'multiple-portals','pause','spacing','acw-update','acw-pending','manual-paused','pause-return-off','first-done','off',
    'available','offline-control','retry','starting','device-passive','coordination']);
  const timestamp = value => typeof value === 'string' && value.length <= 32 && Number.isFinite(Date.parse(value)) ? value : null;
  const fresh = (value, now) => value && now >= Date.parse(value) && now - Date.parse(value) <= AUTOMATION_STATUS_MAX_AGE;

  function validateAutomationStatus(value, now = Date.now()) {
    if (!value || value.version !== 1 || !timestamp(value.reportedAt) || !fresh(value.reportedAt, now)) return null;
    const options = value.options;
    if (!options || !['first','spacing','break','lunch','timed'].every(key => typeof options[key] === 'boolean') ||
        !Number.isInteger(options.minutes) || options.minutes < 1 || options.minutes > 60 ||
        typeof value.recording !== 'boolean' || typeof value.paused !== 'boolean' ||
        !['authenticated','logged-out','unknown'].includes(value.portal) || !['connected','incoming','idle','unknown'].includes(value.call)) return null;
    return {
      version: 1, reportedAt: value.reportedAt, observedAt: timestamp(value.observedAt),
      reason: reasons$1.has(value.reason) ? value.reason : 'portal-state', recording: value.recording, paused: value.paused,
      portal: value.portal, call: value.call, review: value.review === true,
      devicePassive: value.devicePassive === true, coordinationConfirmed: typeof value.coordinationConfirmed === 'boolean' ? value.coordinationConfirmed : null,
      scheduleVerified: value.scheduleVerified === true, startAt: timestamp(value.startAt), endAt: timestamp(value.endAt),
      waitUntil: timestamp(value.waitUntil), acwObservedAt: timestamp(value.acwObservedAt),
      connectionAt: timestamp(value.connectionAt) && Date.parse(value.connectionAt) <= now ? value.connectionAt : null,
      pauseType: ['break','lunch'].includes(value.pauseType) ? value.pauseType : null,
      pauseActual: typeof value.pauseActual === 'boolean' ? value.pauseActual : null, pauseEndsAt: timestamp(value.pauseEndsAt),
      queued: Number.isInteger(value.queued) ? Math.max(0, Math.min(200, value.queued)) : 0,
      options: Object.fromEntries(['first','spacing','break','lunch','timed','minutes'].map(key => [key, options[key]])),
    };
  }

  function automationStatusView(snapshot, now = Date.now()) {
    if (!snapshot) return { key: 'missing', seconds: null };
    if (!fresh(snapshot.reportedAt, now)) return { key: 'stale', seconds: null };
    if (snapshot.review) return { key: 'review', seconds: null };
    if (!snapshot.recording) return { key: 'recording-off', seconds: null };
    if (snapshot.paused) return { key: 'manual-paused', seconds: null };
    if (!fresh(snapshot.observedAt, now)) return { key: 'stale', seconds: null };
    if (snapshot.portal !== 'authenticated') return { key: 'connection', seconds: null };
    if (snapshot.call === 'connected') return { key: 'in-call', seconds: null };
    if (snapshot.call === 'incoming') return { key: 'incoming', seconds: null };
    if (snapshot.devicePassive) return { key: 'device-passive', seconds: null };
    if (snapshot.coordinationConfirmed === false) return { key: 'coordination', seconds: null };
    if (snapshot.reason === 'before-shift' && !snapshot.options.first) return {
      key: snapshot.options.spacing || snapshot.options.break || snapshot.options.lunch ? 'before-shift-manual' : 'off', seconds: null,
    };
    if (snapshot.reason === 'before-shift' && snapshot.startAt && now >= Date.parse(snapshot.startAt)) return { key: 'confirming', seconds: null };
    if (snapshot.reason === 'spacing') {
      if (!fresh(snapshot.acwObservedAt, now) || !snapshot.waitUntil) return { key: 'acw-pending', seconds: null };
      const seconds = Math.ceil((Date.parse(snapshot.waitUntil) - now) / 1000);
      return { key: seconds > 0 ? 'spacing' : 'confirming', seconds: seconds > 0 ? seconds : null };
    }
    return { key: snapshot.reason, seconds: null };
  }

  // The extension popup uses Spanish independently of the tracker's language.
  const translateText = text => text;
  const displayLocale = () => 'es-MX';
  const ui = (parts, ...values) => parts.map((part, index) => part + (values[index] ?? '')).join('');

  function momentLabel(value, now) {
    if (typeof value !== 'string' || !Number.isFinite(Date.parse(value))) return '';
    const date = new Date(value), today = new Date(now);
    return date.toLocaleString(displayLocale(), { hour:'2-digit', minute:'2-digit',
      ...(date.toDateString() === today.toDateString() ? {} : { month:'short', day:'numeric' }) });
  }

  function pauseDescription(snapshot, now) {
    if (snapshot.devicePassive || snapshot.coordinationConfirmed === false) return translateText('Esta PC registra llamadas y conserva tus opciones, pero no pulsa Start Calls ni Stop Calls ni termina pausas automáticamente.');
    const type = snapshot.pauseType === 'break' ? 'Break' : snapshot.pauseType === 'lunch' ? 'Lunch' : null;
    const mode = snapshot.options.timed
      ? translateText('Cierre automático solo para pausas con regreso activado y duración configurada.')
      : translateText('Las pausas terminan cuando pulsás Terminar Break o Terminar Lunch en Inicio.');
    if (!type || snapshot.reason !== 'pause' || snapshot.pauseActual === null) return mode;
    const end = momentLabel(snapshot.pauseEndsAt, now);
    if (!snapshot.pauseActual) return end
      ? ui`${type} programado hasta ${end}. No hay una pausa activa registrada; se respeta el horario.` : mode;
    const auto = snapshot.options.timed && snapshot.options[snapshot.pauseType] && end;
    if (auto && Date.parse(snapshot.pauseEndsAt) <= now) return ui`La duración prevista de ${type} ya se cumplió. Esperando confirmar su cierre en Inicio.`;
    const timing = end ? ui`Duración prevista de ${type}: hasta ${end}. ` : ui`${type} sin duración prevista confirmada. `;
    return timing + (auto
      ? translateText('La extensión intentará cerrar la pausa y volver a disponibilidad si el turno y la conexión lo permiten.')
      : (snapshot.options[snapshot.pauseType]
        ? translateText('Terminá la pausa en Inicio; después se intentará ponerte disponible dentro del turno.')
        : translateText('Terminá la pausa en Inicio y pulsá Start Calls en Propio cuando quieras volver.')));
  }

  function statusMessages(key, snapshot) {
    const messages = {
      missing: [translateText('Sin conexión confirmada'), translateText('Abrí Propio y comprobá que la extensión de Chrome esté activada. Los controles manuales siguen disponibles.')],
      stale: [translateText('Esperando una lectura reciente'), translateText('La extensión debe confirmar el estado de Propio antes de mostrar la próxima acción.')],
      'recording-off': [translateText('Registro automático apagado'), translateText('Activá Registrar mi actividad en la extensión de Chrome para usar las opciones automáticas.')],
      'manual-paused': [translateText('Pausada por vos'), translateText('El registro de llamadas continúa. Reanudá la disponibilidad desde la extensión o con Start Calls en Propio.')],
      'device-passive': [translateText('Solo registro en esta PC'), translateText('Esta PC registra llamadas y conserva tus opciones, pero no pulsa Start Calls ni Stop Calls ni termina pausas automáticamente.')],
      coordination: [translateText('Esperando permiso para esta PC'), translateText('Otra PC puede estar usando la disponibilidad automática, o falta conexión con la nube. El registro continúa. Pausá los iniciadores de la PC anterior; el permiso vence en hasta 30 segundos.')],
      review: [translateText('La conexión necesita revisión'), translateText('Abrí el estado de conexión de la extensión para ver qué necesita atención. El inicio automático espera.')],
      connection: [translateText('Esperando tu sesión de Propio'), translateText('Abrí Propio con tu sesión para que la extensión pueda confirmar la disponibilidad.')],
      schedule: [translateText('Esperando confirmar tu horario'), translateText('La extensión necesita el horario y los descansos actuales antes de actuar.')],
      'shift-ended': [translateText('Fuera de tu turno'), translateText('La extensión no inicia disponibilidad después de finalizar el turno o su horario.')],
      'before-shift': [translateText('Esperando el inicio de tu turno'), translateText('Aunque Propio ya esté abierto, la disponibilidad espera tu horario.')],
      'before-shift-manual': [translateText('Antes del horario de disponibilidad'), translateText('El inicio automático del turno está apagado. Los regresos de pausas y la espera entre llamadas conservan sus opciones.')],
      'in-call': [translateText('Estás en llamada'), translateText('La extensión registra la actividad y no toca los controles de una llamada conectada.')],
      incoming: [translateText('Tenés una llamada entrante'), translateText('Vos elegís si aceptarla. La extensión espera tu decisión.')],
      'portal-state': [translateText('Esperando confirmar el estado de Propio'), translateText('La extensión espera un estado claro antes de tocar Start Calls o Stop Calls.')],
      'multiple-portals': [translateText('Hay varias pestañas de Propio'), translateText('Dejá una sola pestaña del portal para evitar actuar sobre la sesión equivocada.')],
      pause: [snapshot?.pauseType === 'lunch' ? translateText('En Lunch') : snapshot?.pauseType === 'break' ? translateText('En Break') : translateText('Esperando que termine tu pausa'),
        translateText('La disponibilidad respeta tu descanso y la opción de regreso que elegiste.')],
      spacing: [translateText('Próximo intento'), ui`Al alcanzar ${snapshot?.options.minutes} minutos de ACW, la extensión de Chrome intentará pulsar Start Calls.`],
      'acw-update': [translateText('La aplicación necesita actualizarse'), translateText('Recargá Propio Shift Tracker cuando estés libre para compartir su ACW actual con la extensión de Chrome.')],
      'acw-pending': [translateText('Esperando confirmar tu ACW'), translateText('La extensión necesita una lectura reciente del contador antes de volver a ponerte disponible.')],
      'pause-return-off': [translateText('Regreso de esta pausa en manual'), translateText('Pulsá Start Calls en Propio cuando quieras volver. La espera entre llamadas no sustituye esta elección.')],
      'first-done': [translateText('Inicio del turno ya utilizado'), translateText('El inicio del turno ya se utilizó. Los regresos de pausas y la espera conservan sus opciones independientes.')],
      off: [translateText('Sin inicio automático pendiente'), translateText('Vos pulsás Start Calls cuando quieras estar disponible. Podés revisar tus opciones en la extensión.')],
      available: [translateText('Ya estás disponible en Propio'), translateText('La próxima llamada queda a tu elección. La extensión no acepta llamadas por vos.')],
      'offline-control': [translateText('Esperando el control Start Calls'), translateText('Propio debe confirmar Offline o Not Available y habilitar el botón antes del próximo intento.')],
      retry: [translateText('Esperando para reintentar'), translateText('La extensión deja un intervalo entre intentos de disponibilidad.')],
      starting: [translateText('Intentando ponerte disponible'), translateText('La extensión ha solicitado Start Calls. Esperamos la confirmación de Propio.')],
      confirming: [translateText('Confirmando la próxima acción'), translateText('Ya se alcanzó la hora prevista. La extensión vuelve a comprobar las condiciones antes de actuar.')],
    };
    return messages[key] || messages['portal-state'];
  }

  function installAutomationStatusUi({ host = window, document = host.document, now = () => Date.now(), getWorkSession = () => null } = {}) {
    const panel = document.getElementById('automationPanel');
    if (!panel) return { update() {}, stop() {} };
    let snapshot = null, closed = false;
    const element = id => document.getElementById(id);
    const setText = (id, text) => { const node = element(id); if (node && node.textContent !== text) node.textContent = text; };
    function render() {
      if (closed) return;
      const brief = element('automationStatusBtn');
      if (brief) brief.hidden = document.getElementById('pageHome')?.hidden === true;
      const current = automationStatusView(snapshot, now()), [title, detail] = statusMessages(current.key, snapshot);
      setText('automationTitle', title); setText('automationDetail', current.key === 'pause' ? pauseDescription(snapshot, now()) : detail);
      const timer = element('automationCountdown');
      if(timer.dataset)timer.dataset.kind=current.key;
      timer.hidden = current.seconds === null && current.key !== 'before-shift';
      const clock = current.seconds !== null ? `${Math.floor(current.seconds / 60)}:${String(current.seconds % 60).padStart(2, '0')}`
        : current.key === 'before-shift' && snapshot.startAt ? new Date(snapshot.startAt).toLocaleTimeString(displayLocale(), { hour:'2-digit', minute:'2-digit' }) : '';
      setText('automationCountdown', clock);
      const briefTimer = element('automationCompactCountdown');
      if (briefTimer) { briefTimer.hidden = timer.hidden; setText('automationCompactCountdown', clock); }
      setText('automationCompactTitle', current.key === 'spacing' ? translateText('en') : current.key === 'missing' ? translateText('Sin confirmar') : title);
      const acwProgress=element('automationAcwProgress'),acwBar=element('automationAcwProgressBar');
      if(acwProgress){acwProgress.hidden=current.key!=='spacing';if(current.key==='spacing'){const total=snapshot.options.minutes*60,elapsed=Math.max(0,Math.min(total,total-current.seconds));if(acwBar)acwBar.value=elapsed/total*100;setText('automationAcwProgressLabel',ui`ACW actual: ${Math.floor(elapsed/60)}:${String(elapsed%60).padStart(2,'0')} de ${snapshot.options.minutes} min`);}}
      const recent = snapshot && now() >= Date.parse(snapshot.reportedAt) && now() - Date.parse(snapshot.reportedAt) <= AUTOMATION_STATUS_MAX_AGE;
      const observed = recent && snapshot.observedAt && now() >= Date.parse(snapshot.observedAt) && now() - Date.parse(snapshot.observedAt) <= AUTOMATION_STATUS_MAX_AGE;
      setText('automationTrackerCheck', recent ? translateText('Aplicación y cuenta reconocidas') : translateText('Esperando confirmar la conexión de la extensión'));
      setText('automationPortalCheck', observed && snapshot.portal === 'authenticated' ? translateText('Sesión de Propio reconocida') : translateText('Sesión de Propio pendiente de confirmar'));
      setText('automationScheduleCheck', recent && snapshot.scheduleVerified ? translateText('Horario y descansos confirmados') : translateText('Horario y descansos pendientes de confirmar'));
      setText('automationOptionsCheck', recent ? ui`Espera entre llamadas: ${snapshot.options.spacing ? ui`${snapshot.options.minutes} minutos de ACW` : translateText('apagada')}` : translateText('Esperando tus opciones actuales'));
      setText('automationHoursCheck',recent&&snapshot.scheduleVerified&&snapshot.startAt&&snapshot.endAt?`${momentLabel(snapshot.startAt,now())} – ${momentLabel(snapshot.endAt,now())}`:'');
      setText('automationFirstCheck', recent ? ui`Inicio automático del turno: ${snapshot.options.first ? translateText('activado') : translateText('apagado')}` : '');
      setText('automationReturnsCheck', recent ? ui`Regreso automático: Break ${snapshot.options.break ? translateText('activado') : translateText('apagado')} · Lunch ${snapshot.options.lunch ? translateText('activado') : translateText('apagado')}` : '');
      setText('automationPauseCheck', recent ? pauseDescription(snapshot, now()) : '');
      setText('automationConnectionCheck', observed && snapshot.portal === 'authenticated' && snapshot.connectionAt
        ? ui`Conexión a Propio detectada: ${momentLabel(snapshot.connectionAt, now())}` : '');
      let work;
      try { work = getWorkSession(); } catch { work = null; }
      const at = momentLabel(work?.startedAt, now()), end = momentLabel(work?.endedAt, now());
      const workText = !at ? '' : end && Date.parse(work.endedAt) < Date.parse(work.startedAt)
        ? translateText('Esta sesión se cerró antes del comienzo laboral; no sumó tiempo de trabajo.')
        : Date.parse(work.startedAt) > now() ? ui`Inicio laboral previsto: ${at}. La conexión anterior no suma ACW ni tiempo de trabajo.`
        : work.manual ? ui`Inicio laboral manual: ${at}.`
        : work.callAtStart && recent && snapshot.startAt && Date.parse(work.startedAt) < Date.parse(snapshot.startAt)
          ? ui`Inicio laboral: ${at}; se registró una llamada antes del horario.` : ui`Inicio laboral: ${at}.`;
      setText('automationWorkCheck', workText + (end && Date.parse(work.endedAt) >= Date.parse(work.startedAt) ? ui` Cierre de sesión: ${end}.` : ''));
    }
    const timer = host.setInterval(render, 1000);
    const observer = new host.MutationObserver(render);
    const home = element('pageHome');
    if (home) observer.observe(home, { attributes:true, attributeFilter:['hidden'] });
    function stop() { closed = true; snapshot = null; host.clearInterval(timer); observer.disconnect(); host.removeEventListener('pagehide', stop); }
    host.addEventListener('pagehide', stop, { once:true });
    render();
    return { update(raw) {
      if (closed) return;
      const next = validateAutomationStatus(raw, now());
      if (raw === null) snapshot = null;
      else if (next && (!snapshot || Date.parse(next.reportedAt) >= Date.parse(snapshot.reportedAt))) snapshot = next;
      render();
    }, stop };
  }

  const portalDarkKey = 'propio-dark-mode-v1';

  document.getElementById('extensionVersion').textContent = chrome.runtime.getManifest().version;
  let nativeLayout = null, layoutChoice = null;

  const reasons = {
    'portal-closed': 'La pestaña de Propio se cerró durante una llamada. Revisá su final en Propio Shift Tracker.',
    'active-portal-call': 'Esperá a que termine la llamada para pausar o cambiar de cuenta. Para detener la conexión de inmediato, descartá las señales y revisá la llamada activa en Propio Shift Tracker.',
    'multiple-trackers': 'Dejá abierta una sola pestaña de Propio Shift Tracker para esta cuenta.',
    'tracker-closed': 'Abrí Propio Shift Tracker e iniciá sesión para conectarlo.',
    'pending-account': 'Hay llamadas pendientes de la cuenta anterior. Abrila para completar el registro.',
    'account-needed': 'Abrí Propio Shift Tracker, iniciá sesión y conectá esta cuenta antes de activar el registro.',
    'queue-full': 'La cola está llena. El registro se pausó; revisá las llamadas pendientes.',
    'expired-event': 'Hay una señal de más de 24 horas. El registro se pausó para revisarla.',
    'event-rejected': 'Una señal no pasó la validación. El registro está pausado.',
    'tracker-needs-review': 'Propio Shift Tracker requiere revisión: puede haber una llamada manual, un traslape o un problema al guardar.',
    storage: 'No se pudo guardar el estado. Reintentá la conexión.',
    'invalid-spacing': 'Elegí un número entero de 1 a 60 minutos.',
    'invalid-reinforcement': 'No se pudo cambiar el refuerzo positivo. Reintentá.',
    'app-timeout': 'Propio Shift Tracker no respondió. Reintentá en unos segundos.',
    'update-tracker': 'Actualizá Propio Shift Tracker para usar esta opción.',
    'stale-tab': 'Esa pestaña de Propio Shift Tracker quedó vieja. Recargala e intentá de nuevo.',
  };
  const labels = { history: 'Historial oficial recuperado', 'session-start': 'Sesión iniciada · Shift', 'session-end': 'Sesión cerrada · Shift', incoming: 'Llamada entrante', accepted: 'Llamada aceptada', rejected: 'Llamada rechazada', disconnected: 'Llamada terminada', available: 'Disponible', unavailable: 'Fuera de línea' };
  const send = packet => chrome.runtime.sendMessage(packet);
  labels['start-calls'] = 'Disponibilidad automática · Start Calls'; labels['pause-end'] = 'Fin de pausa programado';
  labels['spacing-stop'] = 'Espera entre llamadas · Stop Calls';
  labels['manual-stop'] = 'Pausaste la disponibilidad automática'; labels['manual-start'] = 'Reanudaste con Start Calls';
  const availabilityReasons = {
    connection: 'Esperando la conexión con Propio y Propio Shift Tracker.', schedule: 'La pestaña de Propio Shift Tracker todavía no confirma el horario y los descansos.',
    'shift-ended': 'Fuera del turno: no pulsa Start Calls.', 'before-shift': 'Esperando la hora de inicio de tu turno.',
    review: 'La conexión necesita revisión antes de empezar.', 'in-call': 'Estás en llamada; no toca los controles.',
    incoming: 'Hay una llamada entrante. Vos elegís si aceptarla.', 'portal-state': 'Esperando un estado claro de Propio.',
    'multiple-portals': 'Hay más de una pestaña de Propio, o todavía no se confirma la única pestaña.',
    pause: 'Esperando que termine tu Break o Lunch.', spacing: 'Respetando tu espera entre llamadas.',
    'acw-update': 'Actualizá Propio Shift Tracker para usar su contador ACW.',
    'acw-pending': 'Esperando el ACW actualizado de Propio Shift Tracker.',
    'manual-paused': 'Disponibilidad automática pausada por vos. El registro de llamadas continúa.',
    'pause-return-off': 'El regreso de esta pausa está apagado. Vos pulsás Start Calls para volver.',
    'first-done': 'La primera llamada ya fue tomada. El regreso de Break/Lunch sigue funcionando si está encendido.',
    off: 'No hay un iniciador pendiente.', available: 'Ya estás disponible en Propio.',
    'offline-control': 'Esperando Offline o Not Available con Start Calls disponible.',
    retry: 'Esperando un momento antes de reintentar Start Calls.', starting: 'Pulsando Start Calls para ponerte disponible.',
    stale: 'Lectura atrasada. Esperando confirmar Propio de nuevo; no se pulsa Start Calls ni Stop Calls.',
    'recording-off': 'El registro automático está apagado.',
    'device-passive': 'Solo registro en esta PC. No pulsa Start Calls ni Stop Calls ni termina pausas automáticamente.',
    coordination: 'Esperando permiso de la nube para esta PC. Otra PC puede estar usando los iniciadores. El registro continúa; pausá la PC anterior y esperá hasta 30 segundos.',
  };
  let busy = false, feedback = '', feedbackIsOk = false, automationUi = null, workSession = null;
  async function refresh() {
    const state = await send({ kind: 'status' });
    if (!state || state.ok === false) throw new Error('status');
    workSession = state.preparation?.plan?.workSession || null;
    automationUi ||= installAutomationStatusUi({ getWorkSession: () => workSession });
    automationUi.update(state.automationStatus || null);
    document.getElementById('status').textContent = state.mode === 'auto' ? 'Registro automático activo' : state.paired ? 'Listo para registrar' : 'Buscando Propio Shift Tracker';
    document.getElementById('detail').textContent = feedback || reasons[state.attention] || (state.paired ? state.mode === 'auto' ? 'El registro automático está activo.' : 'Activá el registro cuando quieras comenzar.' : 'Se vincula automáticamente al reconocer tu sesión en Propio Shift Tracker.');
    document.getElementById('detail').classList.toggle('error', Boolean((feedback && !feedbackIsOk) || state.attention));
    const badge = document.getElementById('connectionBadge'); badge.textContent = state.paired ? 'Conectada' : 'Esperando'; badge.classList.toggle('connected', state.paired);
    document.getElementById('observedCount').textContent = String(state.completed);
    document.getElementById('historyCount').textContent = state.history ? String(state.history.count) : '—';
    document.getElementById('historyScope').textContent = state.history?.coverage === 'range' ? 'En el historial de hoy' : 'En la página del historial';
    document.getElementById('historyStatus').textContent = state.history
      ? `${state.history.invalid ? `${state.history.invalid} fila(s) pendiente(s) de datos válidos. ` : ''}Última lectura: ${new Date(state.history.at).toLocaleTimeString('es')}.${state.mode !== 'auto' ? ' Activá el registro para sincronizarlas.' : ''}`
      : 'Abrí el historial de Propio para leer y recuperar sus llamadas.';
    document.getElementById('pendingCount').textContent = String(state.queued);
    const queueDetail = document.getElementById('pendingQueueDetail'), queueDeadline = document.getElementById('pendingQueueDeadline');
    queueDetail.hidden = !state.queued;
    const expires = Date.parse(state.queueSummary?.expiresAt), queueRemaining = Math.max(0, Math.ceil((expires - Date.now()) / 60000));
    queueDeadline.textContent = !Number.isFinite(expires) ? 'Pendientes sin fecha confirmada; requieren revisión.'
      : state.queueSummary.expired ? 'Hay señales vencidas; el registro necesita revisión.'
      : `La señal más antigua vence en ${Math.floor(queueRemaining / 60)} h ${queueRemaining % 60} min.`;
    document.getElementById('pair').textContent = state.paired ? 'Revisar conexión' : 'Reintentar conexión';
    document.getElementById('pair').classList.toggle('primary', !state.paired);
    document.getElementById('open').classList.toggle('primary', state.paired);
    const toggle = document.getElementById('automatic');
    const callStatus = state.active ? 'Registrando tu llamada actual.' : state.call === 'connected' ? 'Hay una llamada en curso cuyo inicio no se observó; revisala en Propio Shift Tracker.' : state.call === 'incoming' ? 'Tenés una llamada entrante; vos decidís si aceptarla.' : 'Esperando la próxima llamada.';
    document.getElementById('portalStatus').textContent = !state.paired ? 'Esperando tu sesión en Propio Shift Tracker para vincularla automáticamente. La vista original funciona por separado.' : state.portal === 'authenticated' ? `Sesión reconocida. ${callStatus}` : state.portal === 'logged-out' ? 'Cierre de sesión confirmado en Propio.' : 'Abrí Propio para reconocer tu sesión.';
    toggle.checked = state.mode === 'auto'; toggle.disabled = busy || !state.paired;
    const prep = state.preparation, prepToggle = document.getElementById('prepareFirst');
    document.getElementById('availabilityPaused').checked = prep?.availabilityPaused === true;
    document.getElementById('availabilityPaused').disabled = busy || !state.paired;
    const resumeBtn = document.getElementById('resumeAvailability');
    resumeBtn.hidden = !(state.paired && prep?.availabilityPaused === true); resumeBtn.disabled = busy;
    if (state.paired && prep?.availabilityPaused === true) {
      document.getElementById('status').textContent = 'Disponibilidad en pausa';
      if (!feedback && !state.attention) document.getElementById('detail').textContent = 'Sigue registrando. Reanuda desde aquí o con Start Calls en Propio.';
    }
    const availability = automationStatusView(state.automationStatus);
    document.getElementById('availabilityStatus').textContent = availabilityReasons[availability.key] || availabilityReasons[prep?.waitReason] || 'Comprobando cuándo ponerte disponible.';
    nativeLayout = state.layout;
    if (layoutChoice) renderLayout(layoutChoice);
    const spacing = prep?.spacing || { enabled: false, minutes: 2 };
    document.getElementById('spacingEnabled').checked = spacing.enabled === true;
    document.getElementById('spacingEnabled').disabled = busy || !state.paired;
    const minutesInput = document.getElementById('spacingMinutes');
    if (document.activeElement !== minutesInput) minutesInput.value = spacing.minutes;
    document.getElementById('spacingSummary').textContent = `ACW ${spacing.minutes} min`;
    minutesInput.disabled = busy || !state.paired;
    const remaining = Math.max(0, Math.ceil((Date.parse(spacing.waitUntil) - Date.now()) / 1000));
    document.getElementById('spacingStatus').textContent = !spacing.enabled ? 'Apagado. No agrega esperas entre llamadas.'
      : prep?.availabilityPaused ? 'La disponibilidad automática está pausada por vos.'
      : prep?.waitReason === 'pause-return-off' ? 'El regreso de esta pausa está apagado. Vos decidís cuándo volver.'
      : prep?.waitReason === 'pause' ? 'La espera no interrumpe tu Break o Lunch.'
      : prep?.waitReason === 'spacing' && remaining > 0 ? `Faltan ${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')} para volver a estar disponible.`
      : `Vuelve a estar disponible cuando el ACW de Propio Shift Tracker llega a ${spacing.minutes} minuto(s).`;
    prepToggle.checked = prep?.enabled === true; prepToggle.disabled = busy || !state.paired;
    const plan = prep?.plan;
    const refreshTracker = document.getElementById('refreshTracker');
    refreshTracker.hidden = !state.paired || !plan || (plan.scheduleVerified === true && !(spacing.enabled && plan.acwVerified === false));
    refreshTracker.disabled = busy || state.active || state.call === 'connected' || state.call === 'incoming';
    const reinforcement = prep?.reinforcement || { celebrate: false, ask: false };
    for (const [id, key] of [['bridgeCelebrate', 'celebrate'], ['bridgeAsk', 'ask']]) {
      const input = document.getElementById(id); input.checked = reinforcement[key] === true; input.disabled = busy || !state.paired || !prep?.reinforcement;
    }
    document.getElementById('reinforcementStatus').textContent = !state.paired ? 'Conectá Propio Shift Tracker para cambiar esto.'
      : !prep?.reinforcement ? 'Actualizá Propio Shift Tracker para usar esta opción.'
      : 'Es el mismo ajuste del menú de Propio Shift Tracker.';
    const resume = prep?.resume || { break: false, lunch: false, mode: 'manual' };
    for (const [id, name] of [['resumeBreak','break'],['resumeLunch','lunch']]) {
      const input = document.getElementById(id); input.checked = resume[name]; input.disabled = busy || !state.paired;
    }
    document.getElementById('resumeMode').value = resume.mode; document.getElementById('resumeMode').disabled = busy || !state.paired;
    document.getElementById('resumeStatus').textContent = resume.mode === 'timed'
      ? 'Al cumplir la duración de tu horario, cierra la pausa y te pone disponible. También podés terminarla vos en Inicio. Mantené Propio Shift Tracker abierto.'
      : 'Vos terminás la pausa en Inicio. Después, la extensión te pone disponible automáticamente.';
    for (const id of ['pair', 'open']) document.getElementById(id).disabled = busy;
    document.getElementById('reviewed').hidden = !state.queued && !(state.mode === 'auto' && state.active);
    const list = document.getElementById('signals'); list.replaceChildren();
    for (const item of [...state.last].reverse()) {
      const li = document.createElement('li');
      li.textContent = `${labels[item.signal] || 'Señal'} · ${new Date(item.at).toLocaleTimeString('es')}`; list.append(li);
    }
    if (!state.last.length) { const li = document.createElement('li'); li.textContent = 'Todavía no se detectaron señales compatibles.'; list.append(li); }
    const diagnostic = state.diagnostic || { requests: 0, recognized: 0, last: [] };
    document.getElementById('connectionHealth').textContent = reasons[state.attention] || (!state.paired ? 'Esperando tu sesión de Propio Shift Tracker para conectar.'
      : state.portal === 'authenticated' ? `Propio está abierto y tu sesión fue reconocida. ${callStatus}`
      : state.portal === 'logged-out' ? 'Saliste de Propio. Esperando que vuelvas a entrar.' : 'Tu cuenta está vinculada. Esperando que Propio confirme tu sesión.');
    document.getElementById('detectorStatus').textContent = diagnostic.requests
      ? `${diagnostic.requests} solicitud(es) observada(s) · ${diagnostic.recognized} señal(es) reconocida(s)`
      : 'Todavía no se observaron solicitudes del portal.';
    const requests = document.getElementById('detectorRequests'); requests.replaceChildren();
    const kinds = { status: 'Estado de Propio', twilio: 'Evento de llamadas', 'portal-api': 'Otra solicitud del portal' };
    const formats = { json: 'JSON', form: 'Formulario', missing: 'Cuerpo no disponible', oversized: 'Cuerpo demasiado grande', unreadable: 'Formato no reconocido', 'not-read': 'Cuerpo no leído' };
    for (const item of [...diagnostic.last].reverse()) {
      const li = document.createElement('li');
      li.textContent = `${kinds[item.kind] || 'Solicitud'} · ${formats[item.format] || 'Sin formato'} · HTTP ${item.status} · ${item.result === 'recognized' ? 'Señal reconocida' : item.result === 'http-error' ? 'Solicitud fallida' : 'Sin señal compatible'}`;
      requests.append(li);
    }
  }
  async function act(packet, okMessage) {
    if (busy) return;
    busy = true; feedback = ''; feedbackIsOk = false;
    try { const result = await send(packet); if (!result?.ok) feedback = reasons[result?.reason] || 'No se pudo completar la acción.'; else if (okMessage) { feedback = okMessage; feedbackIsOk = true; const shown = okMessage; setTimeout(() => { if (feedback === shown) { feedback = ''; feedbackIsOk = false; refresh().catch(() => {}); } }, 6000); } }
    catch { feedback = reasons.storage; }
    finally { busy = false; await refresh().catch(() => {}); }
  }
  document.getElementById('open').addEventListener('click', () => act({ kind: 'open-tracker' }));
  document.getElementById('pair').addEventListener('click', () => act({ kind: 'pair' }, 'Conexión revisada: Propio Shift Tracker está conectado.'));
  document.getElementById('resumeAvailability').addEventListener('click', () => act({ kind: 'pause-availability', paused: false }));
  document.getElementById('automatic').addEventListener('change', event => act({ kind: 'mode', mode: event.target.checked ? 'auto' : 'observe' }));
  document.getElementById('prepareFirst').addEventListener('change', event => act({ kind: 'prepare-first', enabled: event.target.checked }));
  document.getElementById('availabilityPaused').addEventListener('change', event => act({ kind: 'pause-availability', paused: event.target.checked }));
  document.getElementById('refreshTracker').addEventListener('click', () => act({ kind: 'refresh-tracker' }));
  const saveSpacing = () => act({ kind: 'spacing', enabled: document.getElementById('spacingEnabled').checked, minutes: Number(document.getElementById('spacingMinutes').value) });
  document.getElementById('spacingEnabled').addEventListener('change', saveSpacing);
  document.getElementById('spacingMinutes').addEventListener('change', saveSpacing);
  for (const id of ['bridgeCelebrate', 'bridgeAsk']) document.getElementById(id).addEventListener('change', () => act({ kind: 'reinforcement',
    celebrate: document.getElementById('bridgeCelebrate').checked, ask: document.getElementById('bridgeAsk').checked }));
  for (const id of ['resumeBreak','resumeLunch','resumeMode']) document.getElementById(id).addEventListener('change', () => act({ kind: 'resume-options',
    break: document.getElementById('resumeBreak').checked, lunch: document.getElementById('resumeLunch').checked, mode: document.getElementById('resumeMode').value }));
  document.getElementById('reviewed').addEventListener('click', () => {
    if (window.confirm('¿Ya revisaste o registraste estas llamadas en Propio Shift Tracker? Se descartarán las señales pendientes y volverá el modo de observación. Una llamada activa en Propio Shift Tracker requiere revisión allí.')) act({ kind: 'clear-reviewed' });
  });
  refresh().catch(() => { document.getElementById('status').textContent = reasons.storage; });
  setInterval(() => { if (!busy) refresh().catch(() => {}); }, 2000);

  const layoutKey = 'propio-original-layout-v1';
  let layoutBusy = false, layoutRevision = 0;
  function renderLayout(value) {
    layoutChoice = value || { enabled: false };
    const toggle = document.getElementById('originalLayout');
    toggle.checked = value?.enabled === true;
    toggle.disabled = layoutBusy;
    const states = { 'native-present': 'Componente original detectado en Propio.', loading: 'Esperando que Propio termine de cargar.',
      'waiting-offline': 'Esperando Offline para aplicar la vista sin interrumpir llamadas.',
      'native-missing': 'No se detecta el componente original. Depende de que Propio lo siga incluyendo; la extensión no reemplaza sus totales.' };
    document.getElementById('originalLayoutStatus').textContent = !toggle.checked ? 'Desactivada. Se recuerda en este perfil.'
      : nativeLayout?.revision === value?.revision ? states[nativeLayout.state] || 'Esperando confirmar la vista de Propio.'
      : 'Preferencia activada; falta confirmar el componente en Propio. Abrí una sola pestaña del portal.';
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[layoutKey]) return;
    layoutRevision++; renderLayout(changes[layoutKey].newValue);
  });
  const initialLayoutRevision = layoutRevision;
  chrome.storage.local.get(layoutKey).then(values => {
    if (layoutRevision === initialLayoutRevision) renderLayout(values[layoutKey]);
  }).catch(() => { document.getElementById('originalLayoutStatus').textContent = 'No se pudo leer la preferencia. Reintentá al abrir la extensión.'; });
  document.getElementById('originalLayout').addEventListener('change', async event => {
    if (layoutBusy) return;
    const enabled = event.target.checked;
    layoutBusy = true; event.target.disabled = true;
    try {
      await chrome.storage.local.set({ [layoutKey]: { enabled, revision: crypto.randomUUID() } });
      document.getElementById('originalLayoutStatus').textContent = 'Guardado. Propio se actualizará cuando esté Offline.';
    } catch {
      try { const values = await chrome.storage.local.get(layoutKey); renderLayout(values[layoutKey]); } catch {}
      document.getElementById('originalLayoutStatus').textContent = 'No se pudo guardar. Se conserva la elección anterior; reintentá.';
    } finally { layoutBusy = false; event.target.disabled = false; }
  });

  let darkBusy = false, darkRevision = 0, darkChoice = false;
  function renderPortalDark(value) {
    darkChoice = value?.enabled === true;
    document.getElementById('portalDark').checked = darkChoice;
    document.getElementById('portalDarkStatus').textContent = darkChoice
      ? 'Activado. Tu elección se recuerda en este navegador.'
      : 'Desactivado. Propio conserva sus colores originales.';
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[portalDarkKey]) return;
    darkRevision++;
    renderPortalDark(changes[portalDarkKey].newValue);
  });
  const initialDarkRevision = darkRevision;
  chrome.storage.local.get(portalDarkKey).then(values => {
    if (darkRevision === initialDarkRevision) renderPortalDark(values[portalDarkKey]);
  }).catch(() => { document.getElementById('portalDarkStatus').textContent = 'No se pudo leer la preferencia. Reintentá al abrir la extensión.'; });
  document.getElementById('portalDark').addEventListener('change', async event => {
    if (darkBusy) return;
    const enabled = event.target.checked;
    darkBusy = true; event.target.disabled = true;
    try {
      await chrome.storage.local.set({ [portalDarkKey]: { enabled } });
      renderPortalDark({ enabled });
    } catch {
      renderPortalDark({ enabled: darkChoice });
      document.getElementById('portalDarkStatus').textContent = 'No se pudo guardar. Se conserva la elección anterior; reintentá.';
    } finally { darkBusy = false; event.target.disabled = false; }
  });

})();
