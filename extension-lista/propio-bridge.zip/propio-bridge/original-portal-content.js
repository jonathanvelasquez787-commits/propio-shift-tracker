(function () {
  'use strict';

  // Only fixed classifications leave this isolated content script. Names, IDs,
  // credentials, client details and arbitrary portal text are never serialized.
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const statusText = value => normalize(value).replace(/^call status\s*:?\s*/, '');
  const STATUS_ELEMENTS = '[role="status"],.call-status,#callStatus,[data-call-status],h1,h2,h3,h4,h5,h6,span,p,strong,div,label';
  const labels = {
    signout: /^(sign\s*out|log\s*out|cerrar sesi[oó]n|salir)$/,
    accept: /^(accept( call)?|answer( call)?|aceptar( llamada)?|contestar( llamada)?)$/,
    reject: /^(reject( call)?|decline( call)?|rechazar( llamada)?)$/,
    hangup: /^(hang ?up|end call|disconnect call|colgar|finalizar llamada|terminar llamada)$/,
    idle: /^(start calls|stop calls|iniciar llamadas|detener llamadas)$/,
  };
  function controlKind(element) {
    for (const value of controlTexts(element)) {
      const label = normalize(value);
      for (const [kind, pattern] of Object.entries(labels)) if (pattern.test(label)) return kind;
    }
    return null;
  }
  function controlTexts(element) {
    const clean = element?.cloneNode?.(true);
    clean?.querySelectorAll?.('svg,mat-icon,.material-icons,.material-icons-outlined,[aria-hidden="true"]')?.forEach(icon => icon.remove());
    const value = element?.matches?.('input[type="button"],input[type="submit"]') ? element.value : null;
    return [element?.getAttribute?.('aria-label'), element?.getAttribute?.('title'), clean?.textContent ?? element?.textContent, value];
  }
  function visible(element) {
    if (!element || element.hidden || element.closest('[hidden],[aria-hidden="true"]') || !element.getClientRects().length) return false;
    const style = element.ownerDocument.defaultView.getComputedStyle(element);
    return style.visibility !== 'hidden' && style.display !== 'none';
  }
  function offlineStartButton(document) {
    const observation = readPortalObservation(document);
    if (observation.session !== 'authenticated' || observation.call !== 'idle') return null;
    const offline = [...document.querySelectorAll(STATUS_ELEMENTS)]
      .some(element => visible(element) && /^(offline|not available|no disponible|fuera de l[ií]nea|desconectado)$/.test(statusText(element.textContent)));
    if (!offline) return null;
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]')];
    const matches = controls.filter(element => visible(element) && !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
      controlTexts(element).some(value => /^(start calls|iniciar llamadas)$/.test(normalize(value))));
    return matches.length === 1 ? matches[0] : null;
  }
  function readPortalObservation(document, armed = false) {
    const headings = [...document.querySelectorAll('h1,h2,h3,h4,strong,b,[role="heading"],header,nav,span,p,div,label')];
    const originalName = document.querySelector('app-header .app-interpreter-name');
    const originalWelcome = document.querySelector('app-header .header-welcome-message');
    const originalSession = visible(originalName) && /^.{1,180}\s*\(\d{1,12}\)$/.test(originalName.textContent.trim()) &&
      normalize(originalWelcome?.textContent) === normalize('Welcome, ' + originalName.textContent);
    const welcome = originalSession || headings.some(element => visible(element) && /^welcome,\s+.{1,180}\s*\(\d{1,12}\)$/i.test(element.textContent.trim()));
    const login = document.querySelector('#loginform');
    const session = welcome ? 'authenticated' : visible(login) ? 'logged-out' : 'unknown';
    if (session !== 'authenticated') return { session, call: 'unknown' };
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"],a[title],a[aria-label]')]
      .filter(element => visible(element) && !element.disabled && element.getAttribute('aria-disabled') !== 'true');
    const kinds = controls.map(controlKind);
    const statuses = [...document.querySelectorAll(STATUS_ELEMENTS)]
      .filter(visible).map(element => statusText(element.textContent));
    const connected = statuses.some(text => /^(call in progress|call connected|in call|llamada en curso|llamada conectada|en llamada)$/.test(text));
    const ended = statuses.some(text => /^(call ended|call disconnected|call completed|llamada terminada|llamada finalizada|llamada desconectada)$/.test(text));
    if (kinds.includes('hangup') && (connected || armed)) return { session, call: 'connected' };
    if (statuses.some(text => /^(ringing|enter code|sonando)$/.test(text))) return { session, call: 'incoming' };
    if (kinds.includes('accept') && kinds.includes('reject') && !kinds.includes('hangup')) return { session, call: 'incoming' };
    if (!kinds.includes('hangup') && (ended || kinds.includes('idle'))) return { session, call: 'idle' };
    return { session, call: 'unknown' };
  }

  const key = 'propio-original-layout-v1';
  const protocol = 'pst-original-portal-layout/v1';

  function installOriginalPortal(api, { window, document, reloadAllowed = () => Boolean(offlineStartButton(document)), setTimer = setInterval, clearTimer = clearInterval } = {}) {
    if (window.top !== window || window.location.origin !== 'https://interpreters.propio-ls.com' || !/^\/portal(?:\/|$)/.test(window.location.pathname)) return;
    let current = null, loadedRevision = null, attemptedRevision = null, revision = 0, applying = false, stopped = false;
    const normalize = value => value && typeof value.enabled === 'boolean' && /^[\w-]{12,100}$/.test(value.revision || '') ? { enabled: value.enabled, revision: value.revision } : null;
    const announce = () => {
      window.postMessage({ protocol, enabled: current?.enabled === true }, window.location.origin);
      if (!current || stopped) return;
      const header = document.querySelector('app-header'), native = document.querySelector('app-daily-rollup');
      const state = !current.enabled ? 'disabled' : native ? 'native-present' : !header ? 'loading' : !reloadAllowed() ? 'waiting-offline' : 'native-missing';
      try { Promise.resolve(api.runtime.sendMessage({ kind: 'portal-layout-observation', revision: current.revision, state })).catch(() => {}); }
      catch (error) { if (/extension context invalidated/i.test(String(error?.message))) stop(); }
    };
    async function apply() {
      if (stopped || applying || !current || current.revision === attemptedRevision || !document.querySelector('app-header') || !reloadAllowed()) return;
      const legacyMissing = current.enabled && !document.querySelector('app-daily-rollup');
      if (current.revision === loadedRevision && !legacyMissing) return;
      applying = true;
      try {
        const requestedRevision = current.revision;
        const result = await api.runtime.sendMessage({ kind: 'apply-portal-layout', revision: requestedRevision });
        if (result?.ok) attemptedRevision = requestedRevision;
      }
      catch (error) { if (/extension context invalidated/i.test(String(error?.message))) stop(); }
      finally { applying = false; }
    }
    function changed(changes, area) {
      if (area !== 'local' || !changes[key]) return;
      revision++; current = normalize(changes[key].newValue); announce(); void apply();
    }
    const timer = setTimer(() => { announce(); void apply(); }, 1500);
    function stop() {
      if (stopped) return;
      stopped = true; clearTimer(timer); api.storage.onChanged.removeListener(changed);
    }
    api.storage.onChanged.addListener(changed);
    const initialRevision = revision;
    api.storage.local.get(key).then(values => {
      if (stopped || revision !== initialRevision) return;
      current = normalize(values[key]); loadedRevision = current?.revision; announce(); void apply();
    }).catch(() => {});
    window.addEventListener('pagehide', event => { if (!event.persisted) stop(); });
    return { apply, stop };
  }

  const portalDarkKey = 'propio-dark-mode-v1';

  function installPortalDarkMode(api, { window, document } = {}) {
    if (window.top !== window || window.location.origin !== 'https://interpreters.propio-ls.com' || !/^\/portal(?:\/|$)/.test(window.location.pathname)) return;
    let enabled = false, revision = 0, stopped = false;
    function render() {
      if (stopped || !document.documentElement) return;
      if (enabled) document.documentElement.setAttribute('data-pst-dark', '');
      else document.documentElement.removeAttribute('data-pst-dark');
    }
    function changed(changes, area) {
      if (stopped || area !== 'local' || !changes[portalDarkKey]) return;
      revision++;
      enabled = changes[portalDarkKey].newValue?.enabled === true;
      render();
    }
    function stop() {
      stopped = true;
      api.storage.onChanged.removeListener(changed);
      document.removeEventListener('DOMContentLoaded', render);
    }
    api.storage.onChanged.addListener(changed);
    document.addEventListener('DOMContentLoaded', render);
    const initialRevision = revision;
    api.storage.local.get(portalDarkKey).then(values => {
      if (stopped || initialRevision !== revision) return;
      enabled = values[portalDarkKey]?.enabled === true;
      render();
    }).catch(() => {});
    window.addEventListener('pagehide', event => { if (!event.persisted) stop(); });
    return { stop };
  }

  installOriginalPortal(chrome, { window, document });
  installPortalDarkMode(chrome, { window, document });

})();
