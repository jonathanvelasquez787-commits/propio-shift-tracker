function parsePortalNumber(value) {
  let text = String(value ?? '').trim().replace(/^(-?)\s*(?:USD\s*|\$\s*)/i, '$1').replace(/[\s\u00a0]/g, '');
  if (!/^-?(?:\d[\d.,]*|[.,]\d+)$/.test(text)) return null;
  if (text.includes(',') && text.includes('.')) {
    const decimal = text.lastIndexOf(',') > text.lastIndexOf('.') ? ',' : '.';
    const group = decimal === ',' ? '.' : ',';
    const parts = text.split(decimal);
    if (parts.length !== 2 || !/^\d+$/.test(parts[1])) return null;
    const escaped = group === '.' ? '\\.' : ',';
    if (!new RegExp(`^-?\\d{1,3}(?:${escaped}\\d{3})+$`).test(parts[0])) return null;
    text = text.split(group).join('').replace(decimal, '.');
  } else if (text.includes(',')) {
    text = /^-?\d{1,3}(?:,\d{3})+$/.test(text) ? text.replace(/,/g, '') : text.replace(',', '.');
  }
  if (!/^-?(?:\d+(?:\.\d+)?|\.\d+)$/.test(text)) return null;
  const number = Number(text);
  return Number.isFinite(number) && Math.abs(number) <= 100000000 ? number : null;
}

function validatePortalRecord(value, now = Date.now()) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const { customerId, callDate, callStart, billable, dropped } = value;
  if (typeof customerId !== 'string' || !/^\d{1,20}$/.test(customerId)) return null;
  const date = typeof callDate === 'string' && callDate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  const clock = typeof callStart === 'string' && callStart.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!date || !clock || !/^(Yes|No)$/i.test(billable || '') || !/^(Yes|No)$/i.test(dropped || '')) return null;
  const [month, day, year] = date.slice(1).map(Number), hour = Number(clock[1]), minute = Number(clock[2]);
  if (year < 2000 || year > 2100 || hour < 1 || hour > 12 || minute > 59) return null;
  const start = new Date(year, month - 1, day, hour % 12 + (clock[3].toUpperCase() === 'PM' ? 12 : 0), minute);
  if (start.getFullYear() !== year || start.getMonth() !== month - 1 || start.getDate() !== day) return null;
  const durationMin = parsePortalNumber(value.durationMin), amount = parsePortalNumber(value.pay);
  if (durationMin === null || durationMin < 0 || durationMin > 1440 || amount === null || amount < 0 || amount > 100000) return null;
  if (start.getTime() + durationMin * 60000 > now) return null;
  return { customerId, callDate, callStart: `${hour}:${String(minute).padStart(2, '0')} ${clock[3].toUpperCase()}`,
    durationMin, billable: /^yes$/i.test(billable) ? 'Yes' : 'No', dropped: /^yes$/i.test(dropped) ? 'Yes' : 'No', pay: `$${amount.toFixed(2)}` };
}

function portalRecordKey(record) { return `${record.customerId}|${record.callDate}|${record.callStart}`; }

const MAX_LEASE_MS = 25000;
const uuid = value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value);

function validateAutomationLease(value, now = Date.now()) {
  if (!value || value.version !== 1 || !uuid(value.owner) || typeof value.grantedAt !== 'string' || typeof value.expiresAt !== 'string') return null;
  const from = Date.parse(value.grantedAt), to = Date.parse(value.expiresAt);
  if (!Number.isFinite(from) || !Number.isFinite(to) || from > now || to <= now || to - from > MAX_LEASE_MS || to <= from) return null;
  return { version: 1, owner: value.owner, grantedAt: value.grantedAt, expiresAt: value.expiresAt };
}

const TRACKER_ORIGIN = 'https://propio-shift-tracker.vercel.app';
const PORTAL_ORIGIN = 'https://interpreters.propio-ls.com';
const TWILIO_EVENT_ORIGINS = Object.freeze(['https://eventgw.twilio.com', 'https://eventgw.us1.twilio.com', 'https://eventgw.ie1.twilio.com', 'https://eventgw.au1.twilio.com']);
const BRIDGE_MAX_AGE = 24 * 60 * 60 * 1000;
const bridgeId = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{12,100}$/.test(value);
const accountScopeValid = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
function validateBridgePlan(value, now = Date.now()) {
  if (!value || typeof value !== 'object' || typeof value.startAt !== 'string' || typeof value.endAt !== 'string') return null;
  const start = Date.parse(value.startAt), end = Date.parse(value.endAt);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start || end - start > BRIDGE_MAX_AGE || Math.abs(start - now) > BRIDGE_MAX_AGE) return null;
  if (value.scheduledPauses !== undefined && (!Array.isArray(value.scheduledPauses) || value.scheduledPauses.length > 100)) return null;
  const scheduledPauses = (value.scheduledPauses || []).map(input => {
    if (!input || !['break','lunch'].includes(input.type) || typeof input.startedAt !== 'string' || typeof input.endedAt !== 'string') return null;
    const from = Date.parse(input.startedAt), to = Date.parse(input.endedAt);
    return Number.isFinite(from) && Number.isFinite(to) && from >= start && to <= end && from < to
      ? { type: input.type, startedAt: new Date(from).toISOString(), endedAt: new Date(to).toISOString() } : null;
  });
  if (scheduledPauses.some(slot => !slot)) return null;
  const pause = (input, completed) => {
    if (!input || !['break','lunch'].includes(input.type) || typeof input.startedAt !== 'string') return null;
    const started = Date.parse(input.startedAt), ended = Date.parse(completed ? input.endedAt : input.endsAt);
    if (!Number.isFinite(started) || started > now || now - started > BRIDGE_MAX_AGE) return null;
    return { type: input.type, startedAt: new Date(started).toISOString(),
      [completed ? 'endedAt' : 'endsAt']: Number.isFinite(ended) && ended > started && ended - started <= BRIDGE_MAX_AGE && (!completed || ended <= now) ? new Date(ended).toISOString() : null };
  };
  const acwStart = Date.parse(value.acw?.startedAt), acwObserved = Date.parse(value.acw?.observedAt);
  const acw = typeof value.acw?.startedAt === 'string' && typeof value.acw?.observedAt === 'string' &&
    Number.isFinite(acwStart) && Number.isFinite(acwObserved) && acwStart >= start - BRIDGE_MAX_AGE && acwStart <= acwObserved &&
    acwStart < end && acwObserved <= now + 1000 && now - acwObserved <= BRIDGE_MAX_AGE
      ? { startedAt: new Date(acwStart).toISOString(), observedAt: new Date(acwObserved).toISOString() } : null;
  const work = value.workSession, workStart = typeof work?.startedAt === 'string' ? Date.parse(work.startedAt) : NaN;
  const workEnd = typeof work?.endedAt === 'string' ? Date.parse(work.endedAt) : NaN;
  const workSession = Number.isFinite(workStart) && Math.abs(workStart - now) <= BRIDGE_MAX_AGE
    ? { startedAt: new Date(workStart).toISOString(),
      endedAt: Number.isFinite(workEnd) && Math.abs(workEnd - now) <= BRIDGE_MAX_AGE && workEnd <= now ? new Date(workEnd).toISOString() : null,
      manual: work.manual === true, callAtStart: work.callAtStart === true } : null;
  return { startAt: new Date(start).toISOString(), endAt: new Date(end).toISOString(), hasCall: value.hasCall === true, ended: value.ended === true,
    workSession,
    acw, acwVerified: value.acwVerified !== false && (value.acw === null || !!acw),
    lastCallEndedAt: typeof value.lastCallEndedAt === 'string' && Date.parse(value.lastCallEndedAt) >= start && Date.parse(value.lastCallEndedAt) <= Math.min(now, end) ? new Date(value.lastCallEndedAt).toISOString() : null,
    scheduledPauses, scheduleVerified: Array.isArray(value.scheduledPauses) && value.scheduleVerified !== false,
    pause: pause(value.pause, false), lastPause: pause(value.lastPause, true),
    automationLease: validateAutomationLease(value.automationLease, now) };
}
// Ajustes de refuerzo que viajan entre el popup de la extensión y la app: solo dos booleanos exactos.
function validateBridgeReinforcement(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  if (typeof value.celebrate !== 'boolean' || typeof value.ask !== 'boolean') return null;
  return { celebrate: value.celebrate, ask: value.ask };
}
function validateBridgeEvent(value, now = Date.now()) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1 || !bridgeId(value.id)) return null;
  if (!['call-start','call-end','session-start','session-end','available','unavailable','history-records','pause-end'].includes(value.type)) return null;
  const time = typeof value.at === 'string' ? Date.parse(value.at) : NaN;
  if (!Number.isFinite(time) || time > now + 10000 || now - time > BRIDGE_MAX_AGE) return null;
  const event = { version: 1, id: value.id, type: value.type, at: new Date(time).toISOString() };
  if (value.type === 'pause-end') {
    const start = typeof value.startedAt === 'string' ? Date.parse(value.startedAt) : NaN;
    if (!['break','lunch'].includes(value.pauseType) || !Number.isFinite(start) || start >= time || now - start > BRIDGE_MAX_AGE) return null;
    event.pauseType = value.pauseType; event.startedAt = new Date(start).toISOString();
  }
  if (value.type === 'history-records') {
    if (!Array.isArray(value.records) || !value.records.length || value.records.length > 100) return null;
    event.records = value.records.map(record => validatePortalRecord(record, now));
    if (event.records.some(record => !record)) return null;
  }
  if (value.type.startsWith('session-')) {
    if (!bridgeId(value.sessionId)) return null;
    event.sessionId = value.sessionId;
    if (value.type === 'session-end') {
      const start = Date.parse(value.startedAt);
      if (!Number.isFinite(start) || start > time || now - start > BRIDGE_MAX_AGE) return null;
      event.startedAt = new Date(start).toISOString();
    }
  }
  if (value.type.startsWith('call-')) {
    if (!bridgeId(value.callId)) return null;
    event.callId = value.callId;
    if (value.type === 'call-end') {
      const start = typeof value.startedAt === 'string' ? Date.parse(value.startedAt) : NaN;
      if (!Number.isFinite(start) || start >= time || time-start > BRIDGE_MAX_AGE || now-start > BRIDGE_MAX_AGE) return null;
      event.startedAt = new Date(start).toISOString();
    }
  }
  return event;
}

// Signals are allowlisted from the published add-on; their current portal compatibility still needs observation.
function readPropioSignal(url, body) {
  let target;
  try { target = new URL(url); } catch { return null; }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  if (target.origin === PORTAL_ORIGIN && target.pathname === '/api/Interpreter/UpdateInterpreterStatus') {
    return body.status === 'AV' ? 'available' : body.status === 'LO' ? 'unavailable' : null;
  }
  if (!TWILIO_EVENT_ORIGINS.includes(target.origin) || target.pathname !== '/v4/EndpointEvents') return null;
  return new Map([['incoming', 'incoming'], ['accepted-by-local', 'accepted'], ['rejected-by-local', 'rejected'], ['disconnected-by-local', 'disconnected'], ['disconnected-by-remote', 'disconnected']]).get(body.name) || null;
}

function propioRequestKind(url) {
  let target;
  try { target = new URL(url); } catch { return null; }
  if (target.origin === PORTAL_ORIGIN) {
    if (target.pathname === '/api/Interpreter/UpdateInterpreterStatus') return 'status';
    return 'portal-api';
  }
  return TWILIO_EVENT_ORIGINS.includes(target.origin) && target.pathname === '/v4/EndpointEvents' ? 'twilio' : null;
}

function readPropioRequestBody(requestBody) {
  if (requestBody?.formData && typeof requestBody.formData === 'object') {
    const body = {};
    for (const key of ['name', 'status']) {
      const values = requestBody.formData[key];
      if (Array.isArray(values) && values.length === 1 && typeof values[0] === 'string' && values[0].length <= 64) body[key] = values[0];
    }
    return { body, format: 'form' };
  }
  const raw = requestBody?.raw;
  if (!Array.isArray(raw) || !raw.length || raw.some(part => !part.bytes)) return { body: null, format: 'missing' };
  const parts = raw.map(part => new Uint8Array(part.bytes));
  const length = parts.reduce((size, part) => size + part.length, 0);
  if (length > 65536) return { body: null, format: 'oversized' };
  const bytes = new Uint8Array(length); let offset = 0;
  for (const part of parts) { bytes.set(part, offset); offset += part.length; }
  const text = new TextDecoder().decode(bytes);
  try { return { body: JSON.parse(text), format: 'json' }; } catch {}
  const form = new URLSearchParams(text), body = {};
  for (const key of ['name', 'status']) {
    const values = form.getAll(key);
    if (values.length === 1 && values[0].length <= 64) body[key] = values[0];
  }
  return Object.keys(body).length ? { body, format: 'form' } : { body: null, format: 'unreadable' };
}

function createPropioReducer({ randomId = () => crypto.randomUUID() } = {}) {
  return function reduce(previous, signal, at) {
    const state = { active: previous?.active ? { ...previous.active } : null, completed: Number(previous?.completed) || 0,
      ...(previous?.lastEndedAt ? { lastEndedAt: previous.lastEndedAt } : {}) };
    let event = null;
    if (!Number.isFinite(Date.parse(at))) return { state, event };
    if (signal === 'accepted' && !state.active && !(Date.parse(at) < Date.parse(state.lastEndedAt))) {
      state.active = { callId: randomId(), startedAt: at };
      event = { version: 1, id: randomId(), type: 'call-start', callId: state.active.callId, at };
    } else if (signal === 'disconnected' && state.active && Date.parse(at) > Date.parse(state.active.startedAt)) {
      event = { version: 1, id: randomId(), type: 'call-end', callId: state.active.callId, startedAt: state.active.startedAt, at };
      state.active = null; state.completed++; state.lastEndedAt = at;
    } else if (signal === 'available' || signal === 'unavailable') {
      event = { version: 1, id: randomId(), type: signal, at };
    }
    return { state, event };
  };
}

const AUTOMATION_STATUS_MAX_AGE = 15000;
const reasons = new Set(['connection','schedule','shift-ended','before-shift','review','in-call','incoming','portal-state',
  'multiple-portals','pause','spacing','acw-update','acw-pending','manual-paused','pause-return-off','first-done','off',
  'available','offline-control','retry','starting','device-passive','coordination']);
const timestamp = value => typeof value === 'string' && value.length <= 32 && Number.isFinite(Date.parse(value)) ? value : null;
const fresh$1 = (value, now) => value && now >= Date.parse(value) && now - Date.parse(value) <= AUTOMATION_STATUS_MAX_AGE;

function validateAutomationStatus(value, now = Date.now()) {
  if (!value || value.version !== 1 || !timestamp(value.reportedAt) || !fresh$1(value.reportedAt, now)) return null;
  const options = value.options;
  if (!options || !['first','spacing','break','lunch','timed'].every(key => typeof options[key] === 'boolean') ||
      !Number.isInteger(options.minutes) || options.minutes < 1 || options.minutes > 60 ||
      typeof value.recording !== 'boolean' || typeof value.paused !== 'boolean' ||
      !['authenticated','logged-out','unknown'].includes(value.portal) || !['connected','incoming','idle','unknown'].includes(value.call)) return null;
  return {
    version: 1, reportedAt: value.reportedAt, observedAt: timestamp(value.observedAt),
    reason: reasons.has(value.reason) ? value.reason : 'portal-state', recording: value.recording, paused: value.paused,
    portal: value.portal, call: value.call, review: value.review === true,
    devicePassive: value.devicePassive === true, coordinationConfirmed: typeof value.coordinationConfirmed === 'boolean' ? value.coordinationConfirmed : null,
    scheduleVerified: value.scheduleVerified === true, startAt: timestamp(value.startAt), endAt: timestamp(value.endAt),
    waitUntil: timestamp(value.waitUntil), acwObservedAt: timestamp(value.acwObservedAt),
    connectionAt: timestamp(value.connectionAt) && Date.parse(value.connectionAt) <= now ? value.connectionAt : null,
    pauseType: ['break','lunch'].includes(value.pauseType) ? value.pauseType : null,
    pauseActual: typeof value.pauseActual === 'boolean' ? value.pauseActual : null, pauseEndsAt: timestamp(value.pauseEndsAt),
    queued: Number.isInteger(value.queued) ? Math.max(0, Math.min(200, value.queued)) : 0,
    options: Object.fromEntries(['first','spacing','break','lunch','timed','minutes'].map(key => [key, options[key]])),
  };
}

function createAutomationStatus(state, now = Date.now()) {
  const prep = state.preparation, plan = prep.plan;
  const portals = Object.values(state.tabs).filter(tab => timestamp(tab.seenAt) && Date.parse(tab.seenAt) <= now);
  const recent = portals.filter(tab => tab.observationFresh !== false && fresh$1(tab.seenAt, now));
  const authenticated = recent.filter(tab => tab.session === 'authenticated' && tab.blockedDocument !== tab.documentId);
  const latest = portals.sort((a,b) => Date.parse(b.seenAt) - Date.parse(a.seenAt))[0];
  const observedAt = latest?.observationFresh === false ? null : latest?.seenAt || null;
  const completed = prep.pendingPause?.endedAt ? prep.pendingPause : plan?.lastPause;
  const pause = plan?.pause || plan?.scheduledPauses?.find(slot => now >= Date.parse(slot.startedAt) && now < Date.parse(slot.endedAt) &&
    !(completed?.type === slot.type && Date.parse(completed.startedAt) < Date.parse(slot.endedAt) && Date.parse(completed.endedAt) > Date.parse(slot.startedAt)));
  return validateAutomationStatus({ version: 1, reportedAt: new Date(now).toISOString(), observedAt,
    reason: prep.waitReason, recording: state.mode === 'auto', paused: prep.availabilityPaused === true,
    devicePassive: prep.devicePassive === true, coordinationConfirmed: state.coordinationConfirmed,
    portal: authenticated.length ? 'authenticated' : recent.some(tab => tab.session === 'logged-out') ? 'logged-out' : 'unknown',
    call: ['connected','incoming','idle'].find(kind => authenticated.some(tab => tab.call === kind)) || 'unknown',
    review: Boolean(state.attention && !['tracker-closed'].includes(state.attention)),
    scheduleVerified: plan?.scheduleVerified === true, startAt: plan?.startAt, endAt: plan?.endAt,
    waitUntil: prep.spacing.waitUntil, acwObservedAt: plan?.acw?.observedAt,
    connectionAt: authenticated.length ? state.session?.startedAt : null,
    pauseType: pause?.type, pauseActual: Boolean(plan?.pause), pauseEndsAt: plan?.pause ? pause.endsAt : pause?.endedAt, queued: state.queue.length,
    options: { first: prep.enabled === true, spacing: prep.spacing.enabled === true, minutes: prep.spacing.minutes,
      break: prep.resume.break === true, lunch: prep.resume.lunch === true, timed: prep.resume.mode === 'timed' },
  }, now);
}

const KEY$1 = 'bridge-v1';
const URLS = [`${PORTAL_ORIGIN}/*`, ...TWILIO_EVENT_ORIGINS.map(origin => `${origin}/v4/EndpointEvents*`)];
const SIGN_OUT_DESTINATIONS = new Set(['https://propio.com', 'https://www.propio.com']);
const fresh = () => ({ mode: 'observe', accountScope: null, tabs: {}, session: null, queue: [], completed: 0, last: [], attention: null,
  preparation: { enabled: false, availabilityPaused: false, plan: null, doneFor: null, lastAttemptAt: 0,
    spacing: { enabled: false, minutes: 2, lastEndedAt: null }, waitReason: null,
    resume: { break: false, lunch: false, mode: 'manual' }, pendingPause: null, resumedPauses: [], reinforcement: null } });
function pendingQueueSummary(queue, now = Date.now()) {
  const times = queue.map(item => Date.parse(item?.event?.at)).filter(time => Number.isFinite(time) && time >= 0 && time <= now + 10000);
  if (!times.length) return null;
  const oldest = Math.min(...times), expires = oldest + BRIDGE_MAX_AGE;
  return { oldestAt: new Date(oldest).toISOString(), expiresAt: new Date(expires).toISOString(), expired: now > expires };
}
function createBridgeWorker(api, { now = () => Date.now(), randomId = () => crypto.randomUUID() } = {}) {
  const reduce = createPropioReducer({ randomId }), pending = new Map();
  let serial = Promise.resolve(), flushing = null, acceptedLease = null, leaseDeadline = 0;
  const transact = operation => {
    const result = serial.then(async () => {
      const stored = (await api.storage.local.get(KEY$1))[KEY$1];
      const state = stored?.schema === 1 ? { ...fresh(), ...stored } : fresh();
      state.preparation = { ...fresh().preparation, ...state.preparation, resume: { ...fresh().preparation.resume, ...state.preparation?.resume } };
      state.preparation.spacing = { ...fresh().preparation.spacing, ...state.preparation.spacing };
      const passive = (await api.storage.local.get('automation-device-passive'))['automation-device-passive'];
      if (typeof passive === 'boolean') state.preparation.devicePassive = passive;
      const before = JSON.stringify(state);
      const output = await operation(state);
      if (stored?.schema !== 1 || before !== JSON.stringify(state)) await api.storage.local.set({ [KEY$1]: { ...state, schema: 1 } });
      return output;
    });
    serial = result.catch(() => {});
    return result;
  };
  async function sendToTab(tabId, packet) {
    let timer;
    try {
      return await Promise.race([api.tabs.sendMessage(tabId, packet, { frameId: 0 }),
        new Promise(resolve => { timer = setTimeout(() => resolve(null), 4000); })]);
    } finally { clearTimeout(timer); }
  }
  const ownOrigin = () => { try { return api.runtime?.id ? `chrome-extension://${api.runtime.id}` : null; } catch { return null; } };
  const trackerSender = url => { try { const origin = new URL(url).origin; return origin === TRACKER_ORIGIN || (ownOrigin() !== null && origin === ownOrigin()); } catch { return false; } };
  // La ventana propia del tracker (pagina de la extension) manda sobre la web: si esta abierta y se identifica, las llamadas van solo a ella.
  async function trackers() {
    const own = ownOrigin();
    const ownTabs = own ? await api.tabs.query({ url: `${own}/panel.html*` }) : [];
    const ownFound = (await identify(ownTabs));
    if (ownFound.length) return ownFound;
    return identify(await api.tabs.query({ url: `${TRACKER_ORIGIN}/*` }));
  }
  async function identify(tabs) {
    const results = await Promise.all(tabs.map(async tab => {
      try {
        const ready = await sendToTab(tab.id, { kind: 'identify-tracker', refresh: true });
        return accountScopeValid(ready?.accountScope) ? { tabId: tab.id, accountScope: ready.accountScope, plan: validateBridgePlan(ready.plan, now()), reinforcement: validateBridgeReinforcement(ready.reinforcement) } : null;
      } catch { return null; }
    }));
    return results.filter(Boolean);
  }
  function record(state, signal, at, event) {
    state.last = [...state.last, { signal, at }].slice(-20);
    if (state.mode === 'auto' && state.accountScope && event) {
      if (state.queue.length >= 200) { state.mode = 'observe'; state.attention = 'queue-full'; }
      else state.queue.push({ accountScope: state.accountScope, event });
    }
  }
  function callSignal(state, tabId, signal, at) {
    const { state: reduced, event } = reduce(state.tabs[tabId], signal, at);
    state.tabs[tabId] = { ...state.tabs[tabId], ...reduced };
    if (event?.type === 'call-start' && state.preparation.plan) {
      state.preparation.doneFor = state.preparation.plan.startAt;
      if (state.preparation.pendingPause) finishResume(state);
    }
    if (event?.type === 'call-end' && validateBridgeEvent(event, now())) state.completed++;
    if (event?.type === 'call-end' && validateBridgeEvent(event, now())) state.preparation.spacing.lastEndedAt = event.at;
    record(state, signal, at, event);
  }
  function finishResume(state) {
    const prep = state.preparation;
    if (prep.pendingPause) prep.resumedPauses = [...prep.resumedPauses, prep.pendingPause.startedAt].slice(-100);
    prep.pendingPause = null;
  }
  function setAvailabilityPaused(state, paused) {
    state.preparation.availabilityPaused = paused;
    if (!paused) return;
    state.queue = state.queue.filter(item => item.event.type !== 'pause-end');
    if (state.preparation.pendingPause) state.preparation.pendingPause.requestId = null;
  }
  function updatePlan(state, plan) {
    const prep = state.preparation;
    const cancelPending = () => {
      const requestId = prep.pendingPause?.requestId;
      if (requestId) state.queue = state.queue.filter(item => item.event.id !== requestId);
      prep.pendingPause = null;
    };
    prep.plan = plan;
    const lease = validateAutomationLease(plan?.automationLease, now());
    const sameLease = lease && JSON.stringify(lease) === JSON.stringify(acceptedLease);
    acceptedLease = lease && lease.owner === state.coordinationOwner ? lease : null;
    const nextDeadline = acceptedLease ? performance.now() + Date.parse(acceptedLease.expiresAt) - now() : 0;
    leaseDeadline = sameLease ? Math.min(leaseDeadline, nextDeadline) : nextDeadline;
    if (!plan) return;
    if (plan.ended) { cancelPending(); return; }
    const active = plan.pause;
    const pending = prep.pendingPause;
    const pendingEnd = pending?.endedAt || pending?.endsAt || pending?.startedAt;
    if (pending && (Date.parse(pending.startedAt) >= Date.parse(plan.endAt) ||
        (active?.startedAt !== pending.startedAt && Date.parse(pendingEnd) <= Date.parse(plan.startAt)))) cancelPending();
    if (active) {
      if (!prep.resume[active.type] || prep.resumedPauses.includes(active.startedAt)) { cancelPending(); return; }
      if (prep.pendingPause?.startedAt !== active.startedAt || prep.pendingPause.endsAt !== active.endsAt) {
        cancelPending();
        prep.pendingPause = { ...active, endedAt: null, requestId: null };
      }
    } else if (prep.pendingPause) {
      if (plan.lastPause?.startedAt === prep.pendingPause.startedAt && plan.lastPause.endedAt) prep.pendingPause.endedAt = plan.lastPause.endedAt;
      else if (!prep.pendingPause.endedAt) cancelPending();
    } else if (plan.lastPause?.endedAt && prep.resume[plan.lastPause.type] && !prep.resumedPauses.includes(plan.lastPause.startedAt) &&
        now() - Date.parse(plan.lastPause.endedAt) <= 300000 && (!plan.lastCallEndedAt || Date.parse(plan.lastCallEndedAt) <= Date.parse(plan.lastPause.endedAt))) {
      prep.pendingPause = { ...plan.lastPause, endsAt: null, requestId: null };
    }
  }
  function coordinationReason(state) {
    if (state.preparation.devicePassive === true) return 'device-passive';
    if (!acceptedLease || performance.now() >= leaseDeadline || !validateAutomationLease(acceptedLease, now()) || acceptedLease.owner !== state.coordinationOwner) return 'coordination';
    return null;
  }
  function automationStatus(state) {
    return createAutomationStatus({ ...state, coordinationConfirmed: !coordinationReason(state) }, now());
  }
  function schedulePauseEnd(state, packet) {
    const prep = state.preparation, pause = prep.pendingPause, plan = validateBridgePlan(prep.plan, now());
    if (prep.availabilityPaused || coordinationReason(state) || !pause || prep.resume.mode !== 'timed' || !prep.resume[pause.type] || pause.requestId || pause.endedAt ||
        !pause.endsAt || now() < Date.parse(pause.endsAt) || state.mode !== 'auto' || !state.accountScope || !state.session ||
        !plan || plan.ended || now() < Date.parse(plan.startAt) || now() >= Date.parse(plan.endAt) || plan.pause?.startedAt !== pause.startedAt ||
        packet.session !== 'authenticated' || packet.call !== 'idle' || Object.values(state.tabs).some(tab => tab.active)) return;
    const at = new Date(now()).toISOString(), id = randomId();
    record(state, 'pause-end', at, { version: 1, id, type: 'pause-end', at, startedAt: pause.startedAt, pauseType: pause.type });
    if (state.queue.some(item => item.event.id === id)) pause.requestId = id;
  }
  function prepareFirst(state, tabId, packet) {
    const prep = state.preparation, plan = validateBridgePlan(prep.plan, now());
    prep.spacing.waitUntil = null;
    if (plan?.hasCall || plan?.ended || state.tabs[tabId]?.call === 'connected') { if (plan) prep.doneFor = plan.startAt; }
    const hold = reason => { prep.waitReason = reason; return { prepare: false, stopCalls: false }; };
    const command = action => {
      const commandId = randomId();
      prep.command = { id: commandId, action, at: now(), tabId, documentId: packet.documentId, owner: acceptedLease.owner, accountScope: state.accountScope, plan: JSON.stringify(plan) };
      return { prepare: action === 'start', stopCalls: action === 'stop', authorizationUntil: acceptedLease.expiresAt, commandId };
    };
    if (state.tabs[tabId]?.call === 'connected') { if (prep.pendingPause) finishResume(state); return hold('in-call'); }
    const pending = prep.pendingPause;
    const resumeReady = pending?.endedAt && prep.resume[pending.type];
    const completedPause = pending?.endedAt ? pending : plan?.lastPause;
    const plannedPause = plan?.scheduledPauses.some(slot => now() >= Date.parse(slot.startedAt) && now() < Date.parse(slot.endedAt) &&
      !(completedPause?.type === slot.type && completedPause.endedAt &&
        Date.parse(completedPause.startedAt) < Date.parse(slot.endedAt) && Date.parse(completedPause.endedAt) > Date.parse(slot.startedAt)));
    const firstReady = prep.enabled && plan?.scheduleVerified && prep.doneFor !== plan.startAt && !plan.hasCall && !plannedPause;
    if (state.mode !== 'auto' || !state.accountScope || !state.session || packet.session !== 'authenticated') return hold('connection');
    if (!plan || !plan.scheduleVerified) return hold('schedule');
    if (plan.ended || now() >= Date.parse(plan.endAt)) return hold('shift-ended');
    if (now() < Date.parse(plan.startAt)) return hold('before-shift');
    if (state.attention === 'multiple-trackers' || state.attention === 'tracker-needs-review') return hold('review');
    if (packet.call !== 'idle' || Object.values(state.tabs).some(tab => tab.active)) return hold(packet.call === 'incoming' ? 'incoming' : 'portal-state');
    if (prep.availabilityPaused) return hold('manual-paused');
    const coordination = coordinationReason(state);
    if (coordination) return hold(coordination);
    const portals = Object.entries(state.tabs).filter(([, tab]) => tab.session === 'authenticated' && tab.blockedDocument !== tab.documentId && now() - Date.parse(tab.seenAt) < 15000);
    if (portals.length !== 1 || portals[0][0] !== String(tabId)) return hold('multiple-portals');
    const spacing = prep.spacing;
    const lastEnded = Math.max(Date.parse(spacing.lastEndedAt) || 0, Date.parse(plan.lastCallEndedAt) || 0);
    const spacingReady = spacing.enabled === true && !firstReady && !resumeReady &&
      (plan.hasCall || (lastEnded >= Date.parse(plan.startAt) && lastEnded <= now()));
    if ((plan.pause && !(pending?.endedAt && plan.pause.startedAt === pending.startedAt)) || plannedPause) return hold('pause');
    const lastPauseEnd = Date.parse(plan.lastPause?.endedAt);
    if (Number.isFinite(lastPauseEnd) && !prep.resume[plan.lastPause.type] && lastEnded <= lastPauseEnd) return hold('pause-return-off');
    const acw = plan.acw;
    // A snapshot from before the call ended cannot resume availability afterward.
    const acwFresh = acw && Date.parse(acw.observedAt) <= now() && now() - Date.parse(acw.observedAt) <= 15000 &&
      (!spacing.lastEndedAt || Date.parse(acw.observedAt) >= Date.parse(spacing.lastEndedAt));
    const waitUntil = spacingReady && acwFresh ? Date.parse(acw.startedAt) + spacing.minutes * 60000 : null;
    prep.spacing.waitUntil = waitUntil ? new Date(waitUntil).toISOString() : null;
    if (spacingReady && (!acwFresh || now() < waitUntil)) {
      prep.waitReason = acwFresh ? 'spacing' : plan.acwVerified ? 'acw-pending' : 'acw-update';
      if (packet.available !== true || now() - (prep.lastStopAttemptAt || 0) < 15000) return { prepare: false, stopCalls: false };
      prep.lastStopAttemptAt = now(); record(state, 'spacing-stop', new Date(now()).toISOString(), null);
      return command('stop');
    }
    if (!firstReady && !resumeReady && !spacingReady) return hold(prep.enabled && (prep.doneFor === plan.startAt || plan.hasCall) ? 'first-done' : 'off');
    if (packet.offline !== true) return hold(packet.available === true ? 'available' : 'offline-control');
    if (now() - prep.lastAttemptAt < 15000) return hold('retry');
    prep.lastAttemptAt = now();
    prep.waitReason = 'starting';
    record(state, 'start-calls', new Date(now()).toISOString(), null);
    return command('start');
  }
  function closeSession(state, at) {
    if (!state.session) return;
    for (const [id, tab] of Object.entries(state.tabs)) {
      if (tab.active) callSignal(state, id, 'disconnected', at);
      state.tabs[id].blockedDocument = tab.documentId;
      delete state.tabs[id].signOutPending;
    }
    const session = state.session; state.session = null;
    record(state, 'session-end', at, { version: 1, id: randomId(), type: 'session-end', ...session, at });
  }
  async function navigationCommitted(details) {
    if (details.frameId !== 0 || details.tabId < 0) return;
    try { if (!SIGN_OUT_DESTINATIONS.has(new URL(details.url).origin)) return; } catch { return; }
    // Address-bar visits, bookmarks, reloads and Back are not sign-out evidence.
    if (!['link', 'form_submit'].includes(details.transitionType) &&
        !details.transitionQualifiers?.some(value => ['client_redirect', 'server_redirect'].includes(value))) return;
    if (details.transitionQualifiers?.some(value => ['from_address_bar', 'forward_back'].includes(value))) return;
    await transact(state => {
      const tab = state.tabs[details.tabId], intent = tab?.signOutPending;
      if (!intent || !state.session || intent.sessionId !== state.session.sessionId ||
          now() - intent.at > 60000 || now() < intent.at) return;
      const at = new Date(now()).toISOString();
      closeSession(state, at);
      state.tabs[details.tabId] = { ...state.tabs[details.tabId], session: 'logged-out', call: 'unknown', seenAt: at };
    });
    await flush();
  }
  function beforeRequest(details) {
    const kind = propioRequestKind(details.url);
    if (!kind || details.tabId < 0 || pending.size >= 200) return;
    if (kind === 'portal-api' && details.method !== 'POST' && !['xmlhttprequest', 'websocket'].includes(details.type)) return;
    try { if (new URL(details.initiator).origin !== PORTAL_ORIGIN) return; } catch { return; }
    // Other portal APIs contribute only a counter; never inspect their bodies.
    let signal = null, format = 'not-read';
    try {
      if (kind !== 'portal-api' && details.method === 'POST') {
        const parsed = readPropioRequestBody(details.requestBody);
        format = parsed.format; signal = readPropioSignal(details.url, parsed.body);
      }
      pending.set(details.requestId, { signal, kind, format, tabId: details.tabId, at: new Date(details.timeStamp).toISOString() });
    } catch { /* Raw bodies, headers and URLs are never retained. */ }
  }
  async function completed(details) {
    const item = pending.get(details.requestId); pending.delete(details.requestId);
    if (!item) return;
    await transact(state => {
      const diagnostic = state.diagnostic || { requests: 0, recognized: 0, last: [] };
      const success = details.statusCode >= 200 && details.statusCode < 300;
      state.diagnostic = { requests: Math.min(1000000, diagnostic.requests + 1), recognized: Math.min(1000000, diagnostic.recognized + Number(success && !!item.signal)),
        last: [...diagnostic.last, { kind: item.kind, format: item.format, status: details.statusCode, result: !success ? 'http-error' : item.signal ? 'recognized' : 'unknown', at: item.at }].slice(-20) };
      if (!success || !item.signal) return;
      callSignal(state, item.tabId, item.signal, item.at);
    });
    await flush();
  }
  async function flushOnce() {
    const targets = await trackers();
    // Hold delivery while an account has multiple writable app tabs open.
    const queued = await transact(state => {
      if (state.mode !== 'auto') return null;
      const matched = targets.filter(target => target.accountScope === state.accountScope);
      if (matched.length === 1) {
        updatePlan(state, matched[0].plan);
        if (['multiple-trackers', 'tracker-closed'].includes(state.attention)) state.attention = null;
      } else { updatePlan(state, null); state.attention = matched.length ? 'multiple-trackers' : 'tracker-closed'; }
      if (!state.queue.length) return null;
      if (matched.length !== 1) { state.attention = matched.length ? 'multiple-trackers' : 'tracker-closed'; return null; }
      const item = state.queue[0];
      if (item.event.type === 'pause-end' && coordinationReason(state)) {
        state.queue.shift();
        if (state.preparation.pendingPause?.requestId === item.event.id) state.preparation.pendingPause.requestId = null;
        return null;
      }
      if (item.accountScope !== state.accountScope || !validateBridgeEvent(item.event, now())) {
        state.mode = 'observe'; state.attention = 'expired-event'; return null;
      }
      return { item, tabId: matched[0].tabId };
    });
    if (!queued) return false;
    let ack;
    try { ack = await sendToTab(queued.tabId, { kind: 'deliver-event', accountScope: queued.item.accountScope, event: queued.item.event }); }
    catch { ack = { status: 'blocked', reason: 'tracker-closed' }; }
    return transact(state => {
      if (state.queue[0]?.event.id !== queued.item.event.id || state.accountScope !== queued.item.accountScope) return false;
      if (ack?.status === 'ok') {
        if (queued.item.event.type === 'history-records') state.historySeen = [...(state.historySeen || []), ...queued.item.event.records.map(row => ({ key: portalRecordKey(row), signature: JSON.stringify(row), at: now() }))].slice(-2000);
        if (queued.item.event.type === 'pause-end' && state.preparation.pendingPause?.requestId === queued.item.event.id) {
          if (ack.superseded) finishResume(state);
          else state.preparation.pendingPause.endedAt = queued.item.event.at;
        }
        state.queue.shift(); state.attention = null; return true;
      }
      if (queued.item.event.type === 'pause-end' && ack?.reason === 'coordination') {
        state.queue.shift();
        if (state.preparation.pendingPause?.requestId === queued.item.event.id) state.preparation.pendingPause.requestId = null;
        return false;
      }
      state.attention = ack?.status === 'rejected' ? 'event-rejected' : 'tracker-needs-review';
      if (ack?.status === 'rejected') state.mode = 'observe';
      return false;
    });
  }
  function flush() {
    if (!flushing) flushing = (async () => { for (let i = 0; i < 200 && await flushOnce(); i++) {} })().finally(() => { flushing = null; });
    return flushing;
  }
  async function refreshBackground() {
    await flush();
    const portals = await api.tabs.query({ url: `${PORTAL_ORIGIN}/*` });
    await Promise.allSettled(portals.filter(tab => !tab.discarded && !tab.frozen)
      .map(tab => sendToTab(tab.id, { kind: 'sample-portal' })));
  }
  async function message(packet, sender) {
    if (sender.id !== api.runtime.id) return null;
    if (packet?.kind === 'portal-layout-observation') {
      if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !['disabled','loading','native-present','waiting-offline','native-missing'].includes(packet.state)) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      return transact(async state => {
        const saved = (await api.storage.local.get('propio-original-layout-v1'))['propio-original-layout-v1'];
        if (saved?.revision !== packet.revision || !state.tabs[sender.tab.id]) return null;
        state.tabs[sender.tab.id].layout = { state: packet.state, revision: packet.revision, reportedAt: new Date(now()).toISOString() };
        return { ok: true };
      });
    }
    if (packet?.kind === 'confirm-automation-action') {
      if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id)) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      return transact(state => {
        const prep = state.preparation, command = prep.command, tab = state.tabs[sender.tab.id];
        const elapsed = now() - command?.at;
        if (!command || command.id !== packet.commandId || command.tabId !== sender.tab.id || command.documentId !== packet.documentId ||
            command.owner !== state.coordinationOwner || command.accountScope !== state.accountScope || coordinationReason(state) || prep.availabilityPaused || state.mode !== 'auto' ||
            !Number.isFinite(elapsed) || elapsed < 0 || elapsed > 3000 || JSON.stringify(validateBridgePlan(prep.plan, now())) !== command.plan ||
            !tab || tab.documentId !== packet.documentId || tab.session !== 'authenticated' || tab.call !== 'idle' ||
            Object.values(state.tabs).some(item => item.active || ['incoming','connected'].includes(item.call))) return { ok: false };
        prep.command = null;
        return { ok: true, authorizationUntil: acceptedLease.expiresAt };
      });
    }
    if (packet?.kind === 'apply-portal-layout') {
      if (sender.frameId !== 0 || !sender.tab || !Number.isInteger(sender.tab.id)) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      return transact(async state => {
        const preferences = (await api.storage.local.get('propio-original-layout-v1'))['propio-original-layout-v1'];
        if (!preferences || preferences.revision !== packet.revision || typeof preferences.enabled !== 'boolean') return { ok: false, reason: 'layout-stale' };
        const tab = state.tabs[sender.tab.id];
        const elapsed = now() - Date.parse(tab?.seenAt);
        if (!tab || tab.session !== 'authenticated' || tab.blockedDocument === tab.documentId || tab.call !== 'idle' || !tab.offline || !Number.isFinite(elapsed) || elapsed < 0 || elapsed > 3000 ||
            Object.values(state.tabs).some(item => item.active || ['connected', 'incoming'].includes(item.call)) ||
            (state.preparation.waitReason === 'starting' && now() - state.preparation.lastAttemptAt < 3000)) return { ok: false, reason: 'portal-busy' };
        const portals = await api.tabs.query({ url: `${PORTAL_ORIGIN}/*` });
        if (portals.length !== 1 || portals[0].id !== sender.tab.id) return { ok: false, reason: 'multiple-portals' };
        const previous = (await api.storage.local.get('propio-original-layout-reload'))['propio-original-layout-reload'];
        if (previous?.revision === packet.revision && previous.tabId === sender.tab.id) return { ok: true, alreadyApplied: true };
        await api.storage.local.set({ 'propio-original-layout-reload': { revision: packet.revision, tabId: sender.tab.id } });
        try { await api.tabs.reload(sender.tab.id); }
        catch { await api.storage.local.set({ 'propio-original-layout-reload': previous || null }); return { ok: false, reason: 'layout-reload-failed' }; }
        return { ok: true };
      });
    }
    if (packet?.kind === 'portal-manual-availability') {
      if (sender.frameId !== 0 || !sender.tab || !['start', 'stop'].includes(packet.action)) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      return transact(state => {
        const tab = state.tabs[sender.tab.id];
        if (!state.session || tab?.session !== 'authenticated' || tab.documentId !== packet.documentId || tab.blockedDocument === packet.documentId ||
            now() < Date.parse(tab.seenAt) || now() - Date.parse(tab.seenAt) > 15000) return { ok: false, reason: 'session-not-confirmed' };
        setAvailabilityPaused(state, packet.action === 'stop');
        record(state, packet.action === 'stop' ? 'manual-stop' : 'manual-start', new Date(now()).toISOString(), null);
        return { ok: true };
      });
    }
    if (packet?.kind === 'portal-sign-out') {
      if (sender.frameId !== 0 || !sender.tab || !Number.isInteger(sender.tab.id) || sender.tab.id < 0 || !/^[\w-]{12,100}$/.test(packet.documentId || '')) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      return transact(state => {
        const tab = state.tabs[sender.tab.id];
        if (!state.session || tab?.session !== 'authenticated' || tab.documentId !== packet.documentId || tab.blockedDocument === packet.documentId) return { ok: false, reason: 'session-not-confirmed' };
        tab.signOutPending = { documentId: packet.documentId, sessionId: state.session.sessionId, at: now() };
        return { ok: true };
      });
    }
    if (packet?.kind === 'portal-observation') {
      if (sender.frameId !== 0 || !sender.tab || !Number.isInteger(sender.tab.id) || sender.tab.id < 0) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      if (!/^[\w-]{12,100}$/.test(packet.documentId || '') || !['authenticated', 'logged-out', 'unknown'].includes(packet.session) ||
          !['connected', 'idle', 'incoming', 'unknown'].includes(packet.call) ||
          (packet.signal && !['incoming', 'accepted', 'rejected', 'disconnected'].includes(packet.signal))) return null;
      const at = new Date(now()).toISOString();
      const observed = typeof packet.observedAt === 'string' ? Date.parse(packet.observedAt) : NaN;
      const recentObservation = () => Number.isFinite(observed) && now() >= observed && now() - observed <= 3000;
      await transact(state => {
        const tabId = sender.tab.id, previous = state.tabs[tabId] || {};
        const blocked = previous.blockedDocument === packet.documentId;
        state.tabs[tabId] = { ...previous, documentId: packet.documentId, session: packet.session, call: packet.call, offline: packet.offline === true,
          seenAt: Number.isFinite(observed) ? new Date(observed).toISOString() : at, observationFresh: recentObservation() };
        // A logout page can briefly load inside the portal before the public
        // redirect. Unknown UI keeps the intent; a new authenticated document cancels it.
        if (previous.documentId !== packet.documentId && packet.session === 'authenticated') delete state.tabs[tabId].signOutPending;
        if (packet.session === 'authenticated' && !blocked && !state.session) {
          state.session = { sessionId: randomId(), startedAt: at };
          record(state, 'session-start', at, { version: 1, id: randomId(), type: 'session-start', ...state.session, at });
        } else if (packet.session === 'logged-out' && state.session) {
          // Login remains a fallback when the session expires without a click.
          closeSession(state, at);
        }
        if (packet.session === 'logged-out') delete state.tabs[tabId].blockedDocument;
        if (packet.session === 'authenticated' && !blocked && packet.signal) callSignal(state, tabId, packet.signal, at);
        if (!blocked && recentObservation()) schedulePauseEnd(state, packet);
      });
      await flush();
      return transact(state => ({ ok: true, ...(recentObservation() ? prepareFirst(state, sender.tab.id, packet) : { prepare: false, stopCalls: false }), historyEnabled: state.mode === 'auto' && !!state.accountScope && packet.session === 'authenticated' && packet.call !== 'connected' && !Object.values(state.tabs).some(tab => tab.active) }));
    }
    if (packet?.kind === 'portal-history') {
      if (sender.frameId !== 0 || !sender.tab || !Number.isInteger(sender.tab.id) || sender.tab.id < 0) return null;
      try { if (new URL(sender.url).origin !== PORTAL_ORIGIN) return null; } catch { return null; }
      if (!Number.isSafeInteger(packet.count) || packet.count < 0 || packet.count > 1000000 ||
          !Number.isSafeInteger(packet.invalid) || packet.invalid < 0 || packet.invalid > 1000000 ||
          !Array.isArray(packet.records) || packet.records.length > 100) return null;
      const result = await transact(state => {
        const tab = state.tabs[sender.tab.id];
        if (!tab || tab.documentId !== packet.documentId || tab.session !== 'authenticated' || tab.blockedDocument === packet.documentId) return { ok: false, reason: 'session-not-confirmed' };
        state.history = { count: packet.count, invalid: packet.invalid, at: new Date(now()).toISOString(), coverage: packet.coverage === 'range' ? 'range' : 'page' };
        if (state.mode !== 'auto' || !state.accountScope || tab.call === 'connected' || Object.values(state.tabs).some(tab => tab.active)) return { ok: true };
        const records = packet.records.map(record => validatePortalRecord(record, now()));
        if (records.some(record => !record)) return { ok: false, reason: 'invalid-record' };
        state.historySeen = (state.historySeen || []).filter(item => now() - item.at < 86400000).slice(-2000);
        const freshRecords = records.filter(record => {
          const key = portalRecordKey(record), signature = JSON.stringify(record);
          return !state.historySeen.some(item => item.key === key && item.signature === signature) &&
            !state.queue.some(item => item.event.type === 'history-records' && item.event.records.some(row => portalRecordKey(row) === key && JSON.stringify(row) === signature));
        });
        if (freshRecords.length) record(state, 'history', new Date(now()).toISOString(), { version: 1, id: randomId(), type: 'history-records', at: new Date(now()).toISOString(), records: freshRecords });
        return { ok: true };
      });
      await flush(); return result;
    }
    if (packet?.kind === 'tracker-status') {
      if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !accountScopeValid(packet.accountScope)) return null;
      if (!trackerSender(sender.url)) return null;
      return transact(state => state.accountScope === packet.accountScope ? automationStatus(state) : null);
    }
    if (packet?.kind === 'tracker-coordination') {
      if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !accountScopeValid(packet.accountScope)) return null;
      if (!trackerSender(sender.url)) return null;
      return transact(state => {
        if (state.accountScope !== packet.accountScope) return null;
        if (!state.coordinationOwner) state.coordinationOwner = crypto.randomUUID();
        return { owner: state.coordinationOwner, enabled: state.mode === 'auto' && state.preparation.devicePassive !== true && !state.preparation.availabilityPaused };
      });
    }
    if (packet?.kind === 'tracker-ready') {
      if (sender.frameId !== 0 || !sender.tab || !accountScopeValid(packet.accountScope)) return null;
      if (!trackerSender(sender.url)) return null;
      const targets = await trackers();
      await transact(state => {
        if (!state.accountScope && targets.length > 1) state.attention = 'multiple-trackers';
        if (!state.accountScope && !state.queue.length && targets.length === 1 && targets[0].accountScope === packet.accountScope && targets[0].tabId === sender.tab.id) {
          state.accountScope = targets[0].accountScope;
          state.mode = state.recordingPreference === false ? 'observe' : 'auto';
          state.preparation.enabled = state.firstCallPreference !== false;
          state.tabs = {}; state.session = null; state.attention = null; state.history = null; state.historySeen = [];
        }
        const matched = targets.filter(target => target.accountScope === state.accountScope);
        if (matched.length === 1 && packet.accountScope === state.accountScope) { updatePlan(state, matched[0].plan); state.preparation.reinforcement = matched[0].reinforcement; }
        else if (matched.length > 1) { updatePlan(state, null); state.preparation.reinforcement = null; state.attention = 'multiple-trackers'; }
      });
      await flush(); return { ok: true };
    }
    if (sender.url !== api.runtime.getURL('popup.html')) return null;
    if (packet?.kind === 'device-passive') {
      if (typeof packet.enabled !== 'boolean') return { ok: false, reason: 'invalid-mode' };
      return transact(async state => {
        await api.storage.local.set({ 'automation-device-passive': packet.enabled });
        state.preparation.devicePassive = packet.enabled;
        acceptedLease = null; leaseDeadline = 0;
        state.queue = state.queue.filter(item => item.event.type !== 'pause-end');
        if (state.preparation.pendingPause) state.preparation.pendingPause.requestId = null;
        return { ok: true };
      });
    }
    if (packet?.kind === 'pause-availability') {
      if (typeof packet.paused !== 'boolean') return { ok: false, reason: 'invalid-mode' };
      return transact(state => {
        if (!state.accountScope) return { ok: false, reason: 'account-needed' };
        setAvailabilityPaused(state, packet.paused);
        return { ok: true };
      });
    }
    if (packet?.kind === 'status') {
      const state = await transact(state => ({ ...state }));
      const portals = Object.values(state.tabs).filter(tab => now() - Date.parse(tab.seenAt) < 15000);
      const authenticated = portals.filter(tab => tab.session === 'authenticated' && tab.blockedDocument !== tab.documentId);
      const call = ['connected', 'incoming', 'idle'].find(kind => authenticated.some(tab => tab.call === kind)) || 'unknown';
      const layout = portals.length === 1 && portals[0].layout && now() >= Date.parse(portals[0].layout.reportedAt) && now() - Date.parse(portals[0].layout.reportedAt) < 15000 ? portals[0].layout : null;
      return { mode: state.mode, paired: !!state.accountScope, active: Object.values(state.tabs).some(tab => tab.active), completed: state.completed, history: state.history || null, layout, preparation: state.preparation, automationStatus: automationStatus(state), queued: state.queue.length, queueSummary: pendingQueueSummary(state.queue, now()), queueItems: state.queue.slice(0, 50).map(item => ({ type: item.event.type, at: item.event.at })), last: state.last, attention: state.attention, call, portal: authenticated.length ? 'authenticated' : portals.some(tab => tab.session === 'logged-out') ? 'logged-out' : 'unknown', diagnostic: state.diagnostic || { requests: 0, recognized: 0, last: [] } };
    }
    if (packet?.kind === 'pair') {
      const targets = await trackers();
      if (targets.length !== 1) return { ok: false, reason: targets.length ? 'multiple-trackers' : 'tracker-closed' };
      return transact(state => {
        if (state.accountScope === targets[0].accountScope) { updatePlan(state, targets[0].plan); state.preparation.reinforcement = targets[0].reinforcement; return { ok: true }; }
        if (state.queue.length && state.accountScope !== targets[0].accountScope) return { ok: false, reason: 'pending-account' };
        if (state.mode === 'auto' && Object.values(state.tabs).some(tab => tab.active)) return { ok: false, reason: 'active-portal-call' };
        state.accountScope = targets[0].accountScope; state.mode = 'observe'; state.tabs = {}; state.session = null; state.attention = null; state.history = null; state.historySeen = [];
        state.preparation = { ...fresh().preparation, plan: targets[0].plan, reinforcement: targets[0].reinforcement };
        return { ok: true };
      });
    }
    if (packet?.kind === 'mode') {
      const result = await transact(state => {
        if (!['observe', 'auto'].includes(packet.mode)) return { ok: false, reason: 'invalid-mode' };
        if (packet.mode === 'auto' && !state.accountScope) return { ok: false, reason: 'account-needed' };
        if (packet.mode === 'observe' && state.mode === 'auto' && Object.values(state.tabs).some(tab => tab.active)) return { ok: false, reason: 'active-portal-call' };
        if (state.mode !== packet.mode) { state.tabs = {}; state.session = null; }
        state.mode = packet.mode; state.recordingPreference = packet.mode === 'auto';
        return { ok: true };
      });
      await flush(); return result;
    }
    if (packet?.kind === 'spacing') {
      if (typeof packet.enabled !== 'boolean' || !Number.isInteger(packet.minutes) || packet.minutes < 1 || packet.minutes > 60) return { ok: false, reason: 'invalid-spacing' };
      return transact(state => {
        if (!state.accountScope) return { ok: false, reason: 'account-needed' };
        state.preparation.spacing.enabled = packet.enabled; state.preparation.spacing.minutes = packet.minutes;
        return { ok: true };
      });
    }
    if (packet?.kind === 'reinforcement') {
      const value = validateBridgeReinforcement(packet);
      if (!value) return { ok: false, reason: 'invalid-reinforcement' };
      const scope = await transact(state => state.accountScope);
      if (!scope) return { ok: false, reason: 'account-needed' };
      const matched = (await trackers()).filter(target => target.accountScope === scope);
      if (matched.length !== 1) return { ok: false, reason: matched.length > 1 ? 'multiple-trackers' : 'tracker-closed' };
      let ack;
      try { ack = await sendToTab(matched[0].tabId, { kind: 'deliver-settings', accountScope: scope, reinforcement: value }); }
      catch { ack = { status: 'blocked', reason: 'tracker-closed' }; }
      if (ack?.status !== 'ok') return { ok: false, reason: ack?.reason || 'tracker-closed' };
      return transact(state => {
        if (state.accountScope !== scope) return { ok: false, reason: 'account-needed' };
        state.preparation.reinforcement = value;
        return { ok: true };
      });
    }
    if (packet?.kind === 'prepare-first') {
      if (typeof packet.enabled !== 'boolean') return { ok: false, reason: 'invalid-mode' };
      const targets = await trackers();
      return transact(state => {
        if (!state.accountScope) return { ok: false, reason: 'account-needed' };
        state.preparation.enabled = packet.enabled; state.firstCallPreference = packet.enabled;
        const matched = targets.filter(target => target.accountScope === state.accountScope);
        if (matched.length === 1) updatePlan(state, matched[0].plan);
        else if (matched.length > 1) updatePlan(state, null);
        return { ok: true };
      });
    }
    if (packet?.kind === 'resume-options') {
      if (typeof packet.break !== 'boolean' || typeof packet.lunch !== 'boolean' || !['manual','timed'].includes(packet.mode)) return { ok: false, reason: 'invalid-mode' };
      const targets = await trackers();
      return transact(state => {
        if (!state.accountScope) return { ok: false, reason: 'account-needed' };
        state.preparation.resume = { break: packet.break, lunch: packet.lunch, mode: packet.mode };
        state.queue = state.queue.filter(item => item.event.type !== 'pause-end' || (packet.mode === 'timed' && packet[item.event.pauseType]));
        if (state.preparation.pendingPause?.requestId && !state.queue.some(item => item.event.id === state.preparation.pendingPause.requestId)) state.preparation.pendingPause.requestId = null;
        const matched = targets.filter(target => target.accountScope === state.accountScope);
        updatePlan(state, matched.length === 1 ? matched[0].plan : null);
        return { ok: true };
      });
    }
    if (packet?.kind === 'open-tracker') {
      const existing = (await api.tabs.query({ url: `${TRACKER_ORIGIN}/*` }))[0];
      if (existing && api.tabs.update) {
        await api.tabs.update(existing.id, { active: true });
        if (api.windows?.update && existing.windowId != null) await api.windows.update(existing.windowId, { focused: true });
      } else await api.tabs.create({ url: `${TRACKER_ORIGIN}/` });
      return { ok: true };
    }
    if (packet?.kind === 'refresh-tracker') {
      const targets = await trackers();
      return transact(async state => {
        if (Object.values(state.tabs).some(tab => tab.active || ['connected','incoming'].includes(tab.call))) return { ok: false, reason: 'active-portal-call' };
        const matched = targets.filter(target => target.accountScope === state.accountScope);
        if (matched.length !== 1) return { ok: false, reason: matched.length > 1 ? 'multiple-trackers' : 'tracker-closed' };
        await api.tabs.reload(matched[0].tabId);
        return { ok: true };
      });
    }
    if (packet?.kind === 'clear-reviewed') return transact(state => {
      state.mode = 'observe'; state.recordingPreference = false; state.queue = []; state.tabs = {}; state.session = null; state.attention = null; return { ok: true };
    });
    return null;
  }
  function install() {
    api.webNavigation.onCommitted.addListener(details => { navigationCommitted(details).catch(() => {}); },
      { url: [{ schemes: ['https'], hostEquals: 'propio.com' }, { schemes: ['https'], hostEquals: 'www.propio.com' }] });
    api.webRequest.onBeforeRequest.addListener(beforeRequest, { urls: URLS }, ['requestBody']);
    api.webRequest.onCompleted.addListener(details => { completed(details).catch(() => {}); }, { urls: URLS });
    api.webRequest.onErrorOccurred.addListener(details => { completed({ ...details, statusCode: 0 }).catch(() => {}); }, { urls: URLS });
    api.runtime.onMessage.addListener((packet, sender, respond) => {
      message(packet, sender).then(respond, () => respond({ ok: false, reason: 'storage' })); return true;
    });
    api.alarms.create('retry-bridge', { periodInMinutes: 0.5 });
    api.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'retry-bridge') flush().catch(() => {}); });
    api.tabs.onRemoved.addListener(tabId => { transact(state => {
      if (state.tabs[tabId]?.active) state.attention = 'portal-closed';
      delete state.tabs[tabId];
    }).catch(() => {}); });
  }
  return { install, beforeRequest, completed, message, navigationCommitted, flush, refreshBackground };
}

const preferenceKey = 'workspace-profile-enabled';
const sessionKey = 'workspace-profile-session';
const revisionKey = 'workspace-profile-setup-revision';

function installProfileWorkspace(api, { readDefault = async () => {
  const response = await fetch(api.runtime.getURL('workspace-preferences.json'));
  return response.ok ? await response.json() : { openOnProfileStart: false };
} } = {}) {
  let queue = Promise.resolve();
  function enqueue(task) {
    const result = queue.then(task);
    queue = result.catch(() => {});
    return result;
  }
  async function enabled() {
    const defaults = await readDefault();
    const value = defaults === true || defaults?.openOnProfileStart === true;
    const revision = typeof defaults?.profileSetupRevision === 'string' ? defaults.profileSetupRevision.slice(0, 64) : '';
    const configured = (await api.storage.local.get('workspace-configuration-v1'))['workspace-configuration-v1'];
    if (configured?.version === 1 && typeof configured.openOnProfileStart === 'boolean') {
      const chosen = (await api.storage.local.get(preferenceKey))[preferenceKey];
      return typeof chosen === 'boolean' ? chosen : configured.openOnProfileStart;
    }
    if (revision && (await api.storage.local.get(revisionKey))[revisionKey] !== revision) {
      // Una configuración personal nueva se aplica una vez; luego manda la elección guardada.
      await api.storage.local.set({ [preferenceKey]: value, [revisionKey]: revision });
      await api.storage.session.remove(sessionKey);
      return value;
    }
    const stored = (await api.storage.local.get(preferenceKey))[preferenceKey];
    if (typeof stored === 'boolean') return stored;
    await api.storage.local.set({ [preferenceKey]: value });
    return value;
  }
  async function open({ retryExisting = false } = {}) {
    if (!await enabled()) return { status: 'disabled' };
    const previous = (await api.storage.session.get(sessionKey))[sessionKey];
    if (previous?.prepared) return { status: 'already-prepared' };
    const windows = (await api.windows.getAll({ windowTypes: ['normal'] })).filter(window => !window.incognito);
    if (!windows.length) return { status: 'no-window' };
    const url = api.runtime.getURL('workspace.html#profile');
    const launchers = (await api.runtime.getContexts({ contextTypes: ['TAB'] }))
      .filter(context => !context.incognito && context.tabId >= 0 && context.documentUrl?.split('#')[0] === api.runtime.getURL('workspace.html'));
    await api.storage.session.set({ [sessionKey]: { prepared: true, phase: 'preparing' } });
    try {
      if (launchers.length) {
        // Adoptá el acceso de Windows si llegó junto con el evento del perfil.
        if (launchers[0].documentUrl !== url) await api.tabs.update(launchers[0].tabId, { url });
        else if (retryExisting || previous?.phase === 'failed') await api.tabs.reload(launchers[0].tabId);
        return { status: 'reused' };
      }
      await api.tabs.create({ windowId: windows[0].id, url, active: false });
      return { status: 'opened' };
    } catch (error) {
      await api.storage.session.remove(sessionKey);
      throw error;
    }
  }
  const startup = () => enqueue(open);
  const installed = details => enqueue(async () => {
    if (!['install', 'update'].includes(details.reason)) return { status: 'ignored-install' };
    await api.storage.session.remove(sessionKey);
    return open({ retryExisting: true });
  });
  const created = window => enqueue(async () => {
    if (window.incognito || window.type !== 'normal') return { status: 'ignored-window' };
    return open();
  });
  const removed = () => enqueue(async () => {
    const normal = (await api.windows.getAll({ windowTypes: ['normal'] })).filter(window => !window.incognito);
    if (!normal.length) await api.storage.session.remove(sessionKey);
  });
  const safe = handler => (...args) => { handler(...args).catch(() => {}); };
  api.runtime.onStartup.addListener(safe(startup));
  api.runtime.onInstalled.addListener(safe(installed));
  api.windows.onCreated.addListener(safe(created), { windowTypes: ['normal'] });
  api.windows.onRemoved.addListener(safe(removed), { windowTypes: ['normal'] });
  return { startup, installed, created, removed };
}

const KEY = 'work-tabs-protection';
const ORIGINS = ['https://interpreters.propio-ls.com', 'https://propio-shift-tracker.vercel.app', 'https://app.useinterpreter.com'];
const isWorkTab = tab => {
  try { return !tab.incognito && ORIGINS.includes(new URL(tab.url).origin); } catch { return false; }
};

function installBackgroundTabs(api, refresh) {
  let serial = Promise.resolve(), checking = null;
  const enqueue = operation => {
    const next = serial.then(operation);
    serial = next.catch(() => {});
    return next;
  };
  async function reconcile() {
    const owned = { ...(await api.storage.session.get(KEY))[KEY] };
    const tabs = await api.tabs.query({ url: ORIGINS.map(origin => `${origin}/*`) });
    for (const tab of tabs.filter(isWorkTab)) {
      if (!Number.isInteger(tab.id) || tab.id < 0 || tab.autoDiscardable === false) continue;
      // Record ownership before changing the flag so a restarted worker can restore it.
      owned[tab.id] = true;
      await api.storage.session.set({ [KEY]: owned });
      try { await api.tabs.update(tab.id, { autoDiscardable: false }); } catch { /* Retry on the next check. */ }
    }
    for (const id of Object.keys(owned)) {
      let tab;
      try {
        tab = await api.tabs.get(Number(id));
      } catch { /* Closed tabs need no restoration. */ }
      if (isWorkTab(tab)) continue;
      if (tab) {
        try { await api.tabs.update(Number(id), { autoDiscardable: true }); }
        catch { continue; }
      }
      delete owned[id];
    }
    await api.storage.session.set({ [KEY]: owned });
  }
  function check() {
    if (!checking) checking = enqueue(reconcile).then(refresh).finally(() => { checking = null; });
    return checking;
  }
  const schedule = () => { void check().catch(() => {}); };
  api.tabs.onUpdated.addListener((_id, change) => {
    if (change.url || change.status === 'complete' || change.autoDiscardable === true || change.frozen === false || change.discarded === false) schedule();
  });
  api.tabs.onRemoved.addListener(schedule);
  api.runtime.onStartup.addListener(schedule);
  api.runtime.onInstalled.addListener(schedule);
  api.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'work-tabs-maintenance') schedule(); });
  void api.alarms.create('work-tabs-maintenance', { periodInMinutes: 0.5 });
  schedule();
  return { check };
}

const bridge = createBridgeWorker(chrome);
bridge.install();
installBackgroundTabs(chrome, bridge.refreshBackground);
installProfileWorkspace(chrome);
